#include "fds.h"

extern long his_max_memory;
extern int sys_no;

int dmp_mem = 0;

static struct fds_relay_channel_priv chan_priv_data =
{
	.name = "chan_data",
	.chan = NULL,
	.subbuf_len = SUBBUF_LEN_DATA,
	.subbuf_cnt = SUBBUF_CNT_DATA,
	.packet_cnt = ATOMIC_INIT(0),
	.mapped = false,
	.mem_full = false
};

static struct fds_relay_channel_priv chan_priv_error =
{
	.name = "chan_error",
	.chan = NULL,
	.subbuf_len = SUBBUF_LEN_ERROR,
	.subbuf_cnt = SUBBUF_CNT_ERROR,
	.packet_cnt = ATOMIC_INIT(0),
	.mapped = false
};

static struct fds_relay_channel_priv chan_priv_control =
{
	.name = "chan_control",
	.chan = NULL,
	.subbuf_len = SUBBUF_LEN_CONTROL,
	.subbuf_cnt = SUBBUF_CNT_CONTROL
};

static void data_buf_mapped(struct rchan_buf* rbuf, struct file* pfile)
{
	if (chan_priv_data.chan != NULL)
		relay_reset(chan_priv_data.chan);

	atomic_set(&chan_priv_data.packet_cnt, 0);
	chan_priv_data.mapped = true;
	chan_priv_data.mem_full = false;

	printk("data buffer mapped\n");
}

static void data_buf_unmapped(struct rchan_buf* rbuf, struct file* pfile)
{
	watch_path_cleanup();
	chan_priv_data.mapped = false;

	printk("data buffer unmapped\n");
}

static struct dentry* create_buf_file_handler(
	const char* filename, struct dentry* parent,
#if defined(SYS_UBUNTU) || defined(SYS_ORALINUX)
	umode_t mode,
#else
	int mode,
#endif
	struct rchan_buf* buf, int* is_global)
{
	if (is_global != NULL)
		*is_global = 1;

#if USE_RELAYFS
	return relayfs_create_file(
		filename, parent, 0666, &relay_file_operations, buf);
#else
	return debugfs_create_file(
		filename, 0666, parent, buf, &relay_file_operations);
#endif
}

static int remove_buf_file_handler(struct dentry* dentry)
{
	if (dentry != NULL)
#if USE_RELAYFS
		relayfs_remove_file(dentry);
#else
		debugfs_remove(dentry);
#endif

	return 0;
}


static struct rchan_callbacks data_cbs =
{
	.buf_mapped   = data_buf_mapped,
	.buf_unmapped = data_buf_unmapped,
	.create_buf_file = create_buf_file_handler,
	.remove_buf_file = remove_buf_file_handler
};


static ssize_t control_read(struct file* filep, char __user* usr_buffer, 
	size_t count, loff_t* ppos)
{
	struct fds_relay_channel_priv* priv = NULL;

#ifdef NINE_BRIDGE_SELFTEST
	ssize_t packet_count = 0;
#endif

	char buffer[8] = {0};
	int copy_len = 0;
	copy_len = copy_from_user(buffer, usr_buffer, count);

	if ((buffer[0] & 0xFF) == RELAY_CHAN_DATA)
		priv = &chan_priv_data;
	else if ((buffer[0] & 0xFF) == RELAY_CHAN_ERROR)
		priv = &chan_priv_error;
	else if ((buffer[0] & 0xFF) == GET_KERN_MEM)
		return get_kern_his_max_mem();
	else
		return -1;

	if (priv->chan == NULL || !priv->mapped)
		return -1;

	if (priv->mem_full)
		return 0x0FFFFFFF;

#ifdef NINE_BRIDGE_SELFTEST
	packet_count = atomic_read(&priv->packet_cnt);

	if (packet_count != 0)
		printk("control read return [%ld]\n", packet_count);

	return packet_count;
#else
	return atomic_read(&priv->packet_cnt);
#endif
}

static ssize_t control_write(struct file* filep, const char __user* usr_buffer, 
	size_t count, loff_t* ppos)
{
	char buffer[1024] = {0};
	int copy_len = 0;
	int mapid = 0;
	copy_len = copy_from_user(buffer, usr_buffer, count);

	switch (buffer[0] & 0xFF)
	{
	case MONITOR_PATHS:
                his_max_memory = 0;                

	case MONITOR_MAP_NOT:
	case MONITOR_MAP_SUB:
	case MONITOR_MAP_END:
		return append_watch_paths(buffer, count - 1);
		break;
	case NOTIFY_READ:
		atomic_sub(*((int*)(buffer + 1)), &chan_priv_data.packet_cnt);

#ifdef NINE_BRIDGE_SELFTEST
		printk("consumed %d subbufs, after consume, %d subbufs left\n",
			*((int*)(buffer + 1)),
			atomic_read(&chan_priv_data.packet_cnt));
#endif
		break;
	case NOTIFY_EXIT:
		watch_path_cleanup();
		break;
	case NOTIFY_READ_ERROR:
		atomic_sub(*((int*)(buffer + 1)), &chan_priv_error.packet_cnt);

#ifdef NINE_BRIDGE_SELFTEST
		printk("consumed %d subbufs of errors, %d left\n",
			*((int*)(buffer + 1)),
			atomic_read(&chan_priv_error.packet_cnt));
#endif
		break;
	case SET_KERN_MAX_MEM:
		set_kern_max_memory(*((int*)(buffer + 1)));
		break;
	case NOTIFY_FULL_FINISH:
		mapid = buffer[2];
		fds_add_to_queue_emptyops(FDS_NR_FULLFINISH, mapid);
		break;
	case SET_PID_LOAD:
		set_pid_load(*((pid_t*)(buffer + 1)));
		break;
	case SET_PID_RECV:
		set_pid_recv(*((pid_t*)(buffer + 1)));
		break;
        case NOTIFY_DMP_MEM:
                dmp_mem = *((int*)(buffer + 1)); 
                printk("dmp fzs buf cache size:%dM\n", dmp_mem);
	default:
		break;
	}

	return 0;
}

static struct file_operations control_relay_file_operations =
{
	.read = control_read,
	.write = control_write
};


static struct dentry* control_create_buf_file_handler(
	const char* filename, struct dentry* parent,
#if defined(SYS_UBUNTU) || defined(SYS_ORALINUX)
	umode_t mode,
#else
	int mode,
#endif
	struct rchan_buf* buf, int* is_global)
{
	if (is_global != NULL)
		*is_global = 1;

#if USE_RELAYFS
        return relayfs_create_file(
                filename, parent, 0666, &control_relay_file_operations, buf);
#else
	return debugfs_create_file(
		filename, 0666, parent, buf, &control_relay_file_operations);
#endif
}

static struct rchan_callbacks control_cbs =
{
	.create_buf_file = control_create_buf_file_handler,
	.remove_buf_file = remove_buf_file_handler
	
};

static void error_buf_mapped(struct rchan_buf* rbuf, struct file* pfile)
{
	if (chan_priv_error.chan != NULL)
		relay_reset(chan_priv_error.chan);

	atomic_set(&chan_priv_error.packet_cnt, 0);
	chan_priv_error.mapped = true;

	printk("error buffer mapped\n");
}

static void error_buf_unmapped(struct rchan_buf* rbuf, struct file* pfile)
{
	chan_priv_error.mapped = false;
	printk("error buffer unmapped\n");
}

static struct dentry* error_create_buf_file_handler(
	const char* filename, struct dentry* parent,
#if defined(SYS_UBUNTU) || defined(SYS_ORALINUX)
	umode_t mode,
#else
	int mode,
#endif
	struct rchan_buf* buf, int* is_global)
{
	if (is_global != NULL)
		*is_global = 1;

#if USE_RELAYFS
        return relayfs_create_file(
                filename, parent, 0666, &relay_file_operations, buf);
#else
	return debugfs_create_file(
		filename, 0666, parent, buf, &relay_file_operations);
#endif
}

static struct rchan_callbacks error_cbs =
{
	.buf_mapped = error_buf_mapped,
	.buf_unmapped = error_buf_unmapped,
	.create_buf_file = error_create_buf_file_handler,
	.remove_buf_file = remove_buf_file_handler
};

int relay_init(void)
{
	printk("relay_init begin\n");

#if (RELAYFS_CHANNEL_VERSION >= 7)
#define OPEN_CHANNEL(priv, file, cbs) \
	do { \
		snprintf(priv.path_name, sizeof priv.path_name, "%s%d", \
			file, sys_no); \
		priv.chan = relay_open(priv.path_name, NULL, priv.subbuf_len, \
			priv.subbuf_cnt, cbs, NULL); \
		if (priv.chan == NULL) \
			return -1; \
	} while (0)
#else
#define OPEN_CHANNEL(priv, file, cbs) \
	do { \
		snprintf(priv.path_name, sizeof priv.path_name, "%s%d", \
			file, sys_no); \
		priv.chan = relay_open(priv.path_name, NULL, priv.subbuf_len, \
			priv.subbuf_cnt, cbs); \
		if (priv.chan == NULL) \
			return -1; \
	} while (0)
#endif


	OPEN_CHANNEL(chan_priv_data, FDS_RELAY_CHANNEL_DATA, &data_cbs);
	OPEN_CHANNEL(chan_priv_error, FDS_RELAY_CHANNEL_ERROR, &error_cbs);
	OPEN_CHANNEL(chan_priv_control,FDS_RELAY_CHANNEL_CONTROL, &control_cbs);

#undef OPEN_CHANNEL

	printk("relay init done.\n");

	return 0;
}

void relay_cleanup(void)
{
	while (chan_priv_data.mapped || chan_priv_error.mapped)
	{
		printk("dmp is still using relay, close dmp first\n");
		msleep(1000);
	}

#define FDS_RELAY_CLOSE(rchan) \
	do { if (rchan != NULL) { relay_close(rchan); rchan = NULL; } } while(0)

	FDS_RELAY_CLOSE(chan_priv_data.chan);
	FDS_RELAY_CLOSE(chan_priv_error.chan);
	FDS_RELAY_CLOSE(chan_priv_control.chan);

#undef FDS_RELAY_CLOSE

	printk("relay uninit.\n");
}

static int fds_relay_output(struct fds_relay_channel_priv* priv,
	const char* data, int size)
{
	struct rchan_buf* rbuf = priv->chan->buf[0];

	if (priv->mem_full)
		return 0;

	if (atomic_read(&priv->packet_cnt) == priv->subbuf_cnt)
	{
#ifdef NINE_BRIDGE_SELFTEST
		printk("++++++ buffer of [%s] is full ++++++\n", priv->name);
#endif
		return 1;
	}

	if (rbuf->offset + size > priv->subbuf_len)
	{
		if (rbuf->offset + 4 <= priv->subbuf_len)
                {
                        char *pend = rbuf->data + rbuf->offset;
                        int i = 0;

                        for(i = 0; i < 4; i++)
                            pend[i] = 0;
                }

		rbuf->data += priv->subbuf_len;
		rbuf->offset = 0;

		if (rbuf->data-rbuf->start == priv->subbuf_len*priv->subbuf_cnt)
			rbuf->data = rbuf->start;

		if (atomic_add_return(1, &priv->packet_cnt) == priv->subbuf_cnt)
			return 1;

#ifdef NINE_BRIDGE_SELFTEST
		printk("current wrote %d packets to channel %s\n",
			atomic_read(&priv->packet_cnt), priv->name);
#endif
	}

	if (dummy(data, size))
		return 0;

	memcpy(rbuf->data + rbuf->offset, data, size);
	rbuf->offset += size;

	return 0;
}

int fds_relay_write(const char* data, int size)
{
	if (!chan_priv_data.mapped || chan_priv_data.chan == NULL)
		return 0;

	return fds_relay_output(&chan_priv_data, data, size);
}

void fds_relay_error(const char* data, int size)
{
	if (!chan_priv_error.mapped || chan_priv_error.chan == NULL)
		return;

	fds_relay_output(&chan_priv_error, data, size);
}

void fds_relay_notify_memfull()
{
	fds_queue_cleanup();
	watch_path_cleanup();
	chan_priv_data.mem_full = true;
}

