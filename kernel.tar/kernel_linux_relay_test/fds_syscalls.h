#ifndef NINE_BRIDGE_FDS_SYSCALLS_H
#define NINE_BRIDGE_FDS_SYSCALLS_H

#include "fds_kernel.h"

/* 文件操作类型编号 */
#define FDS_NR_DUMMY    0
#define FDS_NR_OPEN     1
#define FDS_NR_UNLINK   2
#define FDS_NR_WRITE    3
#define FDS_NR_TRUNCATE 4
#define FDS_NR_RENAME   5
#define FDS_NR_MKDIR    6
#define FDS_NR_RMDIR    7

#define FDS_NR_CLOSE 10
#define FDS_NR_FSYNC 11
#define FDS_NR_ESYNC 12

#define FDS_NR_CHOWN       15
#define FDS_NR_FCHOWN      16
#define FDS_NR_LCHOWN      17

#if BITS_PER_LONG == 32
#define FDS_NR_TRUNCATE64  18
#define FDS_NR_FTRUNCATE64 19
#endif

#define FDS_NR_UNLINKAT    23
#define FDS_NR_FCHOWNAT    24
#define FDS_NR_FCHMODAT    25
#define FDS_NR_WRITEV      26
#define FDS_NR_PWRITE64    27
#define FDS_NR_LINK        28
#define FDS_NR_SYMLINK     29
#define FDS_NR_FTRUNCATE   30
#define FDS_NR_CHMOD       31
#define FDS_NR_FCHMOD      32

/* Add by Chuai xiaoming */
#define FDS_NR_LINKAT     50
#define FDS_NR_SENDFILE   51
#define FDS_NR_FULLFINISH 52


#define DEF_INDEX(name) IDX_##name

/* 操作索引号 */
#if HAVE_PWRITEV

#define IDX_fds_write    0
#define IDX_fds_writev   1
#define IDX_fds_pwritev  2
#define IDX_fds_pwrite64 3
#define IDX_COUNT        4

#else

#define IDX_fds_write    0
#define IDX_fds_writev   1
#define IDX_fds_pwrite64 2
#define IDX_COUNT        3

#define IDX_fds_pwritev -1

#endif


#define INVL_OPE_INDEX(idx) ((idx) < 0 || (idx) >= IDX_COUNT)


#ifdef NINE_BRIDGE_IO_FUNC_REF

#define REF_INC(function) \
	do { fds_ref_inc(IDX_##function); } while (0)
#define REF_DEC(function) \
	do { fds_ref_dec(IDX_##function); } while (0)
#define REF_CNT(function) \
	fds_ref_cnt(IDX_##function)

#elif defined NINE_BRIDGE_SELFTEST

#define REF_INC(function) \
	do { atomic_inc(&fds_ope_references[IDX_##function]); } while (0)
#define REF_DEC(function) \
	do { atomic_dec(&fds_ope_references[IDX_##function]); } while (0)
#define REF_CNT(index) \
	atomic_read(&fds_ope_references[index])
#else

#define REF_INC(x)
#define REF_DEC(x)
#define REF_CNT(x)

#endif

extern atomic_t fds_ope_references[IDX_COUNT];

typedef asmlinkage long (*sys_open_t)(
	const char __user* filename, int flags, int mode);
typedef asmlinkage long (*sys_openat_t)(
	int dfd, const char __user* filename, int flags, int mode);
typedef asmlinkage long (*sys_creat_t)(const char __user* pathname, int mode);
typedef asmlinkage long (*sys_read_t)(
	unsigned int fd, char __user* buf, size_t count);
typedef asmlinkage long (*sys_write_t)(
	unsigned int fd, const char __user* buf, size_t count);
typedef asmlinkage long (*sys_writev_t)(
	unsigned long fd, const struct iovec __user* vec, unsigned long vlen);
typedef asmlinkage long (*sys_pwritev_t)(
	unsigned long fd, const struct iovec __user* vec, unsigned long vlen,
	unsigned long pos_l, unsigned long pos_h);
typedef asmlinkage long (*sys_pwrite64_t)(
	unsigned int fd, const char __user* buf, size_t count, loff_t pos);
typedef asmlinkage long (*sys_close_t)(unsigned int fd);
typedef asmlinkage long (*sys_lseek_t)(
	unsigned int fd, off_t offset, unsigned int origin);
typedef asmlinkage long (*sys_mkdir_t)(const char __user* pathname, int mode);
typedef asmlinkage long (*sys_unlink_t)(const char __user* pathname);
typedef asmlinkage long (*sys_unlinkat_t)(
	int dfd, const char __user* pathname, int flag);
typedef asmlinkage long (*sys_link_t)(
	const char __user* oldname, const char __user* newname);
typedef asmlinkage long (*sys_linkat_t)(
	int olddfd, const char __user* oldname,
	int newdfd, const char __user* newname, int flags);
typedef asmlinkage long (*sys_symlink_t)(
	const char __user* oldname, const char __user* newname);
typedef asmlinkage long (*sys_symlinkat_t)(
	const char __user* oldname, int newdfd, const char __user* newname);
typedef asmlinkage long (*sys_rename_t)(
	const char __user* oldname, const char __user* newname);
typedef asmlinkage long (*sys_renameat_t)(
	int olddfd, const char __user* oldname,
	int newdfd, const char __user* newname);
typedef asmlinkage long (*sys_truncate_t)(const char __user* path, long length);
typedef asmlinkage long (*sys_ftruncate_t)(unsigned int fd, long length);
typedef asmlinkage long (*sys_rmdir_t)(const char __user* pathname);
typedef asmlinkage long (*sys_chown_t)(
	const char __user* filename, uid_t user, gid_t group);
typedef asmlinkage long (*sys_lchown_t)(
	const char __user* filename, uid_t user, gid_t group);
typedef asmlinkage long (*sys_fchown_t)(unsigned int fd, uid_t user, gid_t g);
typedef asmlinkage long (*sys_fchownat_t)(int dfd, const char __user* filename,
	uid_t user, gid_t group, int flag);
typedef asmlinkage long (*sys_chmod_t)(const char __user* filename, mode_t m);
typedef asmlinkage long (*sys_fchmod_t)(unsigned int fd, mode_t mode);
typedef asmlinkage long (*sys_fchmodat_t)(
	int dfd, const char __user* filename, mode_t mode);

#if BITS_PER_LONG == 32
typedef asmlinkage long (*sys_truncate64_t)(const char __user* path, loff_t l);
typedef asmlinkage long (*sys_ftruncate64_t)(unsigned int fd, loff_t length);
#endif

extern sys_open_t       old_open;
extern sys_openat_t     old_openat;
extern sys_creat_t      old_creat;
extern sys_unlink_t     old_unlink;
extern sys_write_t      old_write;
extern sys_writev_t     old_writev;
extern sys_pwritev_t    old_pwritev;
extern sys_pwrite64_t   old_pwrite64;
extern sys_close_t      old_close;
extern sys_lseek_t      old_lseek;
extern sys_mkdir_t      old_mkdir;
extern sys_rename_t     old_rename;
extern sys_renameat_t   old_renameat;
extern sys_truncate_t   old_truncate;
extern sys_ftruncate_t  old_ftruncate;
extern sys_rmdir_t      old_rmdir;
extern sys_chown_t      old_chown;
extern sys_lchown_t     old_lchown;
extern sys_fchown_t     old_fchown;
extern sys_fchownat_t   old_fchownat;
extern sys_chmod_t      old_chmod;
extern sys_fchmod_t     old_fchmod;
extern sys_fchmodat_t   old_fchmodat;
extern sys_unlinkat_t   old_unlinkat;
extern sys_link_t       old_link;
extern sys_linkat_t     old_linkat;
extern sys_symlink_t    old_symlink;
extern sys_symlinkat_t  old_symlinkat;
extern sys_symlink_t    old_symlink;

#if BITS_PER_LONG ==32
extern sys_truncate64_t  old_truncate64;
extern sys_ftruncate64_t old_ftruncate64;
#endif


asmlinkage long fds_open(const char __user* filename, int flags, int mode);
asmlinkage long fds_openat(
	int dfd, const char __user* filename, int flags, int mode);
asmlinkage long fds_creat(const char __user* filename, int mode);
asmlinkage long fds_write(unsigned int fd, const char __user* buf, size_t cnt);
asmlinkage long fds_writev(
	unsigned long fd, const struct iovec __user* vec, unsigned long vlen);
asmlinkage long fds_pwritev(
	unsigned long fd, const struct iovec __user* vec, unsigned long vlen,
	unsigned long pos_l, unsigned long pos_h);
asmlinkage long fds_pwrite64(
	unsigned int fd, const char __user* buf, size_t count, loff_t pos);
asmlinkage long fds_close(unsigned int fd);
asmlinkage long fds_lseek(unsigned int fd, off_t offset, unsigned int origin);
asmlinkage long fds_mkdir(const char __user* pathname, int mode);
asmlinkage long fds_unlink(const char __user* pathname);
asmlinkage long fds_unlinkat(int dfd, const char __user* pathname, int flag);
asmlinkage long fds_link(const char __user* oldname,const char __user* newname);
asmlinkage long fds_linkat(
	int olddfd, const char __user* oldname,
	int newdfd, const char __user* newname, int flags);
asmlinkage long fds_symlink(
	const char __user* oldname, const char __user* newname);
asmlinkage long fds_symlinkat(
	const char __user* oldname, int newdfd, const char __user* newname);
asmlinkage long fds_rename(const char __user* oldnm, const char __user* newnm);
asmlinkage long fds_renameat(
	int olddfd, const char __user* oldname,
	int newdfd, const char __user* newname);
asmlinkage long fds_truncate(const char __user* path, long length);
asmlinkage long fds_ftruncate(unsigned int fd, unsigned long length);
asmlinkage long fds_rmdir(const char __user* pathname);
asmlinkage long fds_chown(const char __user* filename, uid_t user, gid_t group);
asmlinkage long fds_lchown(const char __user* filename, uid_t u, gid_t g);
asmlinkage long fds_fchown(unsigned int fd, uid_t user, gid_t group);
asmlinkage long fds_fchownat(int dfd, const char __user* filename,
	uid_t user, gid_t group, int flag);
asmlinkage long fds_chmod(const char __user* filename, mode_t mode);
asmlinkage long fds_fchmod(unsigned int fd, mode_t mode);
asmlinkage long fds_fchmodat(int dfd, const char __user* filename, mode_t mode);

#if BITS_PER_LONG == 32
asmlinkage long fds_truncate64(const char __user* path, loff_t length);
asmlinkage long fds_ftruncate64(unsigned int fd, loff_t length);
#endif

#endif


