#ifndef NINE_BRIDGE_FDS_KERNEL_H
#define NINE_BRIDGE_FDS_KERNEL_H


#include <linux/version.h>
#include <asm/unistd.h>
#include <linux/module.h>
#include <linux/file.h>
#include <linux/syscalls.h>
#include <linux/kthread.h>
#include <linux/debugfs.h>
#include <linux/delay.h>
#include <linux/dcache.h>
#include <linux/sched.h>
#include <linux/uio.h>
#include <linux/slab.h>
#include <linux/namei.h>
#include <linux/nfs_fs.h>
#include <linux/audit.h>
#include <linux/mount.h>
#include <linux/fs_struct.h>
#include <linux/limits.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32))
#  include <asm-generic/atomic-long.h>
#else
#  if !defined(SEEK_SET) || !defined(SEEK_CUR) || !defined(SEEK_END)
#    define SEEK_SET 0
#    define SEEK_CUR 1
#    define SEEK_END 2
#  endif
#  if !defined(bool) || !defined(true) || !defined(false)
#    define bool int
#    define true 1
#    define false 0
#  endif
#endif


#if (FDS_RELAY_VERSION == 7) || defined(SYS_REDHAT)
#  include <linux/relay.h>
#else
#  include <linux/relayfs_fs.h>
#endif

#ifndef MODULE
#define MODULE
#endif

#ifndef LINUX_KERNEL
#define LINUX_KERNEL
#endif


#define USE_RELAYFS (defined(SYS_SUSE) && (RELAYFS_CHANNEL_VERSION == 6))

#define US1        unsigned short
#define ULONG      unsigned long
#define UINT       unsigned int
#define UCHAR      unsigned char


#if BITS_PER_LONG == 32
#  define HAVE_PWRITEV defined(__NR3264_pwritev)
#else
#  define HAVE_PWRITEV defined(__NR_pwritev)
#endif

#endif

