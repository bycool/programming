#ifndef NINE_BRIDGE_FDS_H
#define NINE_BRIDGE_FDS_H

#include <linux/types.h>

#include "fds_kernel.h"
#include "fds_syscalls.h"


#define FPATH_MAXLEN  1024

#define RELAY_CHAN_DATA  '1'
#define RELAY_CHAN_ERROR '2'
#define GET_KERN_MEM     '3'

#define NOTIFY_READ       '1'
#define MONITOR_PATHS     '2'
#define NOTIFY_EXIT       '3'
#define NOTIFY_READ_ERROR '4'
#define MONITOR_MAP_NOT   '5'
#define MONITOR_MAP_SUB   '6'
#define MONITOR_MAP_END   '7'
#define NOTIFY_GETMSG_MEMFULL '8'
#define SET_KERN_MAX_MEM   '9'
#define NOTIFY_FULL_FINISH 'A'
#define SET_PID_LOAD       'B'
#define SET_PID_RECV       'C'
#define NOTIFY_DMP_MEM     'D'

/* MAP宏定义以FDS为依据 */
#define FDS_MAP_PATH_SUB 6
#define FDS_MAP_FILE     7
#define FDS_MAP_NOT_PATH 2
#define FDS_MAP_NOT_FILE 3

#define FDS_RELAY_DIR "fds"
#define FDS_RELAY_CHANNEL_CONTROL ".cchan"
#define FDS_RELAY_CHANNEL_DATA    ".dchan"
#define FDS_RELAY_CHANNEL_ERROR   ".echan"


#define MAX_CONTENT_LEN    3072 /* 3k */

#if defined(SYS_SUSE) && (SYS_VERSION == 10)
#define SUBBUF_LEN_DATA  32768
#define SUBBUF_CNT_DATA  1250
#else
#define SUBBUF_LEN_DATA    33792 /* 33k */
#define SUBBUF_CNT_DATA    5000
#endif

#define SUBBUF_LEN_ERROR 4096
#define SUBBUF_CNT_ERROR 10000
#define SUBBUF_LEN_CONTROL 4096
#define SUBBUF_CNT_CONTROL 1

#define FDS_O_OPENFORMD5 010000000000

#define FDS_OK       0
#define FDS_ERROR   -1
#define FDS_E_ALLOC -0x00001001
#define FDS_E_INVL  -0x00001002


struct fds_relay_channel_priv
{
	char* name;

	struct rchan* chan;
	char path_name[512];

	unsigned int subbuf_len;
	unsigned int subbuf_cnt;

	atomic_t packet_cnt;

	bool mapped;
	bool mem_full;
};

struct fds_monitored_file
{
	struct list_head list;

	int    fd;
	int    pid;
	int    full_sync;
	int    name_len;
	char   name[0];
};

struct serialize_operations
{
	/* 操作码 */
	unsigned char op_code;

	/* 计算序列化数据所需要的空间大小 */
	int (*get_length)(const void* data);

	/* 序列化数据, 并填充到buffer中 */
	void (*serialize_body)(const void* data, char* buffer, int size);
};

struct fds_queue
{
	struct fds_queue* next;
	struct
	{
		int size;
		char* buffer;
	} node;

	bool set_time;
};

struct fds_foperate_info
{
//	char          name[FPATH_MAXLEN]; /* 文件完整路径 */
	char*         name; /* 文件完整路径 */
	int           name_len;           /* 文件完整路径长度 */
	unsigned char op_type;            /* 操作类型编号 */
    unsigned long op_inode;           /* operator所属文件的inode值 */
	unsigned long mtime;
	char          mapid_cnt;
	char*         mapid;			  /* mapid  (1~32)*/ 
	void*         args;               /* 其他参数 */
};

struct fds_dummy_info
{
	unsigned long content_len;
	void* content;
};

struct fds_open_info
{
	int flag;
	int mode;
};

struct fds_write_info
{
	loff_t        offset;
	unsigned long content_len;
	const void*   content;
};

struct fds_mkdir_info
{
	int mode;
};

struct fds_rename_info
{
	char* new_name;
};

struct fds_truncate_info
{
	long length;
};

struct fds_chown_info
{
	uid_t user;
	gid_t group;
	int flag;
};

struct fds_chmod_info
{
	mode_t mode;
};

struct fds_link_info
{
	int flag;
	char* new_name;
};

/* public functions */
/* int fds_get_path(const struct dentry* pdentry, char** path, int* size); */
void fullpath_kis_dot(char* fullpath, int* size);
void fullpath_kis_double_dot(char* fullpath, int* size);
void fullpath_kis_backslash(char* fullpath, int* size);
void fullpath_kis(char* fullpath, int* size);
void figure_to_bytes(char* str, int size, unsigned long num);
size_t fds_get_fullpath_by_fd(unsigned int fd, char* fullpath, unsigned long* op_inode, int size);
size_t fds_get_fullpath_by_fn(const char *ufn, char* fullpath, unsigned long* op_inode, int size, loff_t *file_size);
size_t fds_get_fullpath(
        unsigned int dfd, const char* filename, char* fullpath, unsigned long* op_inode, int size);
void set_pid_load(pid_t pid);
void set_pid_recv(pid_t pid);
bool need_capture_io(void);
bool need_capture_io_nowrite(void);
long fds_get_mtime(void);


#ifdef NINE_BRIDGE_IO_FUNC_REF
void fds_refs_init(void);
void fds_ref_inc(int index);
void fds_ref_dec(int index);
int fds_ref_cnt(int index);
#endif

/* dispatch functions */
int dispatch_start(void);
int dispatch_stop(void);

/* hook functions */
int fds_hook_init(void);
void fds_hook_uninit(void);
void wait_for_unhook_completion(void);

/* monitor functions */
void monitor_cleanup(void);
int add_to_monitor_list(int fd, const char* fullpath, int size, int full_sync);
bool get_name_from_monitor_list(int fd, char* fullpath, int* size);
bool get_name_if_full_sync(int fd, char* fullpath, int* size);
bool get_name_and_close(int fd, char* fullpath, int* size, int* fsync);

/* queue functions */
int fds_alloc_and_init(struct fds_queue** queue);
void fds_free_and_destroy(struct fds_queue** queue);
void fds_append(struct fds_queue* queue);
struct fds_queue* fds_pop(void);
void fds_queue_op_unblock_once(void);
void fds_queue_cleanup(void);
bool dummy(const char* buffer, int size);
void fds_add_to_queue(struct fds_foperate_info* pinfo);
void set_kern_max_memory(int mem);
long get_kern_mem(void);
long get_kern_his_max_mem(void);
struct fds_queue* fds_queue_detach(void);
void fds_add_to_queue_emptyops(unsigned char op_type, int mapid);

/* relay functions */
int relay_init(void);
void relay_cleanup(void);
int fds_relay_write(const char* data, int size);
void fds_relay_error(const char* data, int size);
void fds_relay_notify_memfull(void);

/* serialize functions */
int serialize(const struct fds_foperate_info* pinfo, char** buf, int* size);
int serial_length(const struct fds_foperate_info* pinfo);
int serialize_for_error(
	const struct fds_foperate_info* pinfo, char* buffer, int* size);

/* watch_patch functions */
int append_watch_paths(const char __user* buffer, size_t bytes);
bool monitored(const char* fullpath, bool isdir, char* mapid_cnt, char* mapid);
void watch_path_cleanup(void);
bool watch_path_ready(void);


#endif
 
