#include "fds.h"

pid_t pid_load = (pid_t)-1;
pid_t pid_recv = (pid_t)-1;
extern int is_sys_dst;

void set_pid_load(pid_t pid)
{
	printk("set load pid %d.\n", pid);
	pid_load = pid;
}

void set_pid_recv(pid_t pid)
{
	printk("set recv pid %d.\n", pid);
	pid_recv = pid;
}

bool need_capture_io()
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32))
	return is_sys_dst == 0
		|| !(pid_load == (pid_t)-1
		    || pid_recv == task_tgid_vnr(current)
		    || pid_load == task_tgid_vnr(current));
#else
	return is_sys_dst == 0
		|| !(pid_load == (pid_t)-1
		    || pid_recv == current->tgid
		    || pid_load == current->tgid);
#endif
}

bool need_capture_io_nowrite()
{
	return is_sys_dst == 0;
}

#ifdef NINE_BRIDGE_IO_FUNC_REF
struct fds_pid
{
	struct list_head list;

	int count;
	int pid;
};

static struct list_head fds_refs[IDX_COUNT];
static spinlock_t locks[IDX_COUNT];
#endif


void fullpath_kis_dot(char* fullpath, int* size)
{
	char* ptr = NULL;

	while ((ptr = strstr(fullpath, "/./")) != NULL)
	{
		memmove(ptr, ptr + 2, *size - (ptr + 2 - fullpath));
		*size -= 2;

		fullpath[*size] = '\0';
	}
}

void fullpath_kis_double_dot(char* fullpath, int* size)
{
	char* ptr = NULL;
	char* rptr = NULL;

	while ((ptr = strstr(fullpath, "/../")) != NULL)
	{
		*ptr = 0;
		rptr = strrchr(fullpath, '/');
		if (rptr == NULL)
		{
			memmove(fullpath, ptr + 3,
				*size - (ptr + 3 - fullpath));
			*size -= ptr + 3 - fullpath;
		}
		else
		{
			memmove(rptr, ptr + 3, *size - (ptr + 3 - fullpath));
			*size -= ptr + 3 - rptr;
		}

		fullpath[*size] = '\0';
	}
}

void fullpath_kis_backslash(char* fullpath, int* size)
{
	char* ptr = NULL;

	while ((ptr = strstr(fullpath, "//")) != NULL)
	{
		if (ptr[2] == '\0')
			ptr[1] = '\0';
		else
			memmove(ptr, ptr + 1, *size - (ptr + 1 - fullpath));

		*size -= 1;

		fullpath[*size] = '\0';
	}
}

void fullpath_kis(char* fullpath, int* size)
{
	/* Note: Do not change the order of the following sentences. */
	fullpath_kis_backslash(fullpath, size);
	fullpath_kis_dot(fullpath, size);
	fullpath_kis_double_dot(fullpath, size);
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32))
int fds_get_path(const struct path* ppath, char* path, unsigned long* op_inode, int size)
#else
int fds_get_path(struct dentry* pentry, struct vfsmount* pmnt,
	char* path, unsigned long* op_inode, int size)
#endif
{
	char* pstart = NULL;
	char* tmp_path = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);

        if(!tmp_path)
        {
            printk("file:%s line:%d kmalloc size:%d error\n", __FILE__, __LINE__, PATH_MAX);
            return 0;
        }

        tmp_path[0] = 0;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32))
	pstart = d_path(ppath, tmp_path, PATH_MAX);
        *op_inode = ppath->dentry->d_inode->i_ino;
#else
	pstart = d_path(pentry, pmnt, tmp_path, PATH_MAX);
        *op_inode = pentry->d_inode->i_ino;
#endif
	if (pstart != NULL)
	{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32))
		if (S_ISDIR(ppath->dentry->d_inode->i_mode))
		{
#else
		if (S_ISDIR(pentry->d_inode->i_mode))
		{
#endif
			kfree(tmp_path);
			return snprintf(path, size, "%s/", pstart);
		}
		else
		{
			kfree(tmp_path);
			return snprintf(path, size, "%s", pstart);
		}
	}

	kfree(tmp_path);

	return 0;
}

long fds_get_mtime(void)
{
	struct timeval tv;
	do_gettimeofday(&tv);
	return tv.tv_sec;
}

size_t fds_get_fullpath_by_fd(unsigned int fd, char* fullpath, unsigned long* op_inode, int size)
{
	int path_len = 0;
	struct file* pfile = NULL;

	pfile = fget(fd);
	if (pfile == NULL)
		return 0;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32))
	path_len = fds_get_path(&pfile->f_path, fullpath, op_inode, size);
#else
	path_len = fds_get_path(pfile->f_dentry, pfile->f_vfsmnt, fullpath, op_inode, 
		size);
#endif
	fput(pfile);

	return path_len;
}

#if (LINUX_VERSION_CODE == KERNEL_VERSION(2, 6, 32))
static inline void get_fs_pwd(struct fs_struct* fs, struct path* pwd)
{
	read_lock(&fs->lock);
	*pwd = fs->pwd;
	path_get(pwd);
	read_unlock(&fs->lock);
}
#endif

size_t fds_get_fullpath_by_fn(const char __user* fn, char* fullpath, unsigned long* op_inode, int size, loff_t *file_size)
{
	int path_len = 0;
	char* ufn = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);
        int err = 0;
        loff_t fsize = 0;

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32))
        struct nameidata nd;
	struct dentry* pentry = dget(current->fs->pwd);
	struct vfsmount* pmount = mntget(current->fs->pwdmnt);
#else
	struct path tmp_pwd;
	get_fs_pwd(current->fs, &tmp_pwd);
#endif

        fullpath[0] = 0;

        if(!ufn)
        {   
            printk("file:%s line:%d kmalloc size:%d error\n", __FILE__, __LINE__, PATH_MAX);
            goto ret;
        }   

        ufn[0] = 0;
	if (fn == NULL || strncpy_from_user(ufn, fn, PATH_MAX) == 0)
	{
            goto ret;
	}

	if (*ufn == '/')
		path_len = snprintf(fullpath, size, "%s", ufn);
	else
	{
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32))
		path_len = fds_get_path(pentry, pmount, fullpath, op_inode, size);
#else
		path_len = fds_get_path(&tmp_pwd, fullpath, op_inode, size);
#endif

		if (path_len == 0)
		{
                    goto ret;
		}

		path_len += snprintf(
			fullpath + path_len, size - path_len, "/%s", ufn);
	}

	fullpath_kis(fullpath, &path_len);

ret:
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32))
    dput(pentry);
    mntput(pmount);  
#else
    path_put(&tmp_pwd);
#endif

    if(ufn)
        kfree(ufn);

    if(fullpath[0])
    {
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32))
        err = path_lookup(fullpath,LOOKUP_FOLLOW, &nd);
        if(err<0)
        {
            *op_inode = 0;
        }
        else
        {
            *op_inode = nd.dentry->d_inode->i_ino;
            fsize = nd.dentry->d_inode->i_size;
            path_release(&nd);
        }
#else
        err = kern_path(fullpath, LOOKUP_FOLLOW, &tmp_pwd);
        if(err)
        {
            *op_inode = 0;
        }
        else
        {
            *op_inode = tmp_pwd.dentry->d_inode->i_ino;
            fsize = tmp_pwd.dentry->d_inode->i_size;
            path_put(&tmp_pwd);
        }
#endif
    }

    if(file_size)
        *file_size = fsize;

    //printk("file %s size:%d\n", fullpath, fsize);
    return path_len;
}

size_t fds_get_fullpath(
	unsigned int dfd, const char __user* fn, char* fullpath, unsigned long* op_inode, int size)
{
	int path_len = 0;
	char* filename = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);

        if(!filename)
        {
            printk("file:%s line:%d kmalloc size:%d error\n", __FILE__, __LINE__, PATH_MAX);
            return 0;
        }

        filename[0] = 0;

	if (dfd == AT_FDCWD)
	{
		kfree(filename);
		return fds_get_fullpath_by_fn(fn, fullpath, op_inode, size, 0);
	}

	path_len = fds_get_fullpath_by_fd(dfd, fullpath, op_inode, size);
	if (path_len > 0)
	{
		if (strncpy_from_user(filename, fn, PATH_MAX) == 0)
		{
			kfree(filename);
			return 0;
		}

		path_len += snprintf(fullpath + path_len, size - path_len,
			"/%s", filename);
		fullpath_kis(fullpath, &path_len);
	}

	kfree(filename);

	return path_len;
}


void figure_to_bytes(char* str, int size, unsigned long num)
{
	int i = 0;

	for (i = 0; i < size; ++i)
		str[i] = (unsigned char)((num << (8 * i)) >> ((size - 1) * 8));
}

#ifdef NINE_BRIDGE_IO_FUNC_REF
void fds_refs_init()
{
	int i = 0;

	for (i = 0; i < IDX_COUNT; ++i)
	{
		INIT_LIST_HEAD(&fds_refs[i]);
#if (LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 32))
		locks[i] = __SPIN_LOCK_UNLOCKED(locks[i]);
#else
		locks[i] = SPIN_LOCK_UNLOCKED;
#endif
	}
}

void fds_ref_inc(int index)
{
	struct fds_pid* node = NULL;
	struct fds_pid* new = NULL;

	if (INVL_OPE_INDEX(index))
		return;

	spin_lock_irq(&locks[index]);
	list_for_each_entry(node, &fds_refs[index], list)
	{
		if (node->pid == current->pid)
		{
			++node->count;

			spin_unlock_irq(&locks[index]);
			return;
		}
	}

	new = (struct fds_pid*)kmalloc(sizeof(*new), GFP_ATOMIC);
	if (new == NULL)
	{
		spin_unlock_irq(&locks[index]);
		fds_relay_notify_memfull();
		return ;
	}

	INIT_LIST_HEAD(&new->list);
	new->count = 1;
	new->pid = current->pid;
	list_add(&new->list, &fds_refs[index]);

	spin_unlock_irq(&locks[index]);
}

void fds_ref_dec(int index)
{
	struct fds_pid* node = NULL;

	if (INVL_OPE_INDEX(index))
		return ;

	spin_lock_irq(&locks[index]);
	list_for_each_entry(node, &fds_refs[index], list)
	{
		if (node->pid == current->pid)
		{
			if (--node->count == 0)
			{
				list_del(&node->list);
				kfree(node);
			}

			spin_unlock_irq(&locks[index]);
			return ;
		}
	}
	spin_unlock_irq(&locks[index]);
}

int fds_ref_cnt(int index)
{
	int count = 0;
	struct fds_pid* node = NULL;

	if (INVL_OPE_INDEX(index))
		return 0;

	printk("\n");

	spin_lock_irq(&locks[index]);
	list_for_each_entry(node, &fds_refs[index], list)
	{
		count += node->count;
		printk("pid: [%16d],  ref[%08d]\n", node->pid, node->count);
	}
	spin_unlock_irq(&locks[index]);

	if (count > 0)
		printk("A total of %d refs to function %d.\n", count, index);

	return count;
}

#endif

