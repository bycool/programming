#include "fds.h"

static struct task_struct* thd_disp = NULL;
static struct task_struct* thd_timer = NULL;
static struct timeval stm = {0, 0};
static atomic_t dummy_is_sent = ATOMIC_INIT(0);

static int dispatcher(void* data);
static int fds_on_timer(void* data);

static bool should_stop = false;

int dispatch_start()
{
	atomic_set(&dummy_is_sent, 1);

	thd_disp = kthread_run(dispatcher, NULL, "fds_dispatcher");
	if (thd_disp == NULL)
		return -1;

	thd_timer = kthread_run(fds_on_timer, NULL, "fds_timer");
	if (thd_timer == NULL)
	{
		fds_queue_op_unblock_once();
		kthread_stop(thd_disp);
	}

	printk("dispatch threads started\n");

	return 0;
}

int dispatch_stop()
{
	should_stop = true;

	fds_queue_op_unblock_once();
	kthread_stop(thd_disp);
	kthread_stop(thd_timer);

	fds_queue_cleanup();

	printk("dispatch threads stopped\n");

	return 0;
}

static int dispatcher(void* args)
{
	int rc = 0;
	struct fds_queue* packet = NULL;
	struct fds_queue* pnode = NULL;

	printk("dispather thread ready for work!\n");

	while (!kthread_should_stop())
	{
		if (should_stop)
		{
			msleep(20);
			continue;
		}

		pnode = fds_queue_detach();
		if (pnode == NULL)
		{
			msleep(1);
			continue;
		}

		while (pnode != NULL)
		{
			packet = pnode;
			while ((rc = fds_relay_write(
				packet->node.buffer, packet->node.size)) != 0)
			{
				msleep(1);
			}

			if (packet->set_time)
			{
				do_gettimeofday(&stm);
				atomic_set(&dummy_is_sent, 0);
			}

			pnode = pnode->next;
			fds_free_and_destroy(&packet);
		}
	}

	printk("dispatcher thread exit.\n");

	return 0;
}

static int fds_on_timer(void* args)
{
	int rc = 0;

	struct timeval cur_time = {0, 0};
	struct fds_foperate_info info = {0, 0, FDS_NR_DUMMY, 0, 0, 0, NULL};
	struct fds_queue* dummy = NULL;


	double t1 = .0;
	double t2 = .0;

	printk("Timer thread ready for work!\n");

	while (!kthread_should_stop())
	{
		if (atomic_read(&dummy_is_sent) == 1)
		{
			msleep(20);
			continue;
		}
		else
		{
			do_gettimeofday(&cur_time);
			t1 = cur_time.tv_sec + cur_time.tv_usec / 1000000.0;
			t2 = stm.tv_sec + stm.tv_usec / 1000000.0;
			if (t1 - t2 < 0.05)
			{
				msleep(20);
				continue;
			}
		}

		rc = fds_alloc_and_init(&dummy);
		if (rc != 0)
			continue;

		rc = serialize(&info, &dummy->node.buffer, &dummy->node.size);
		if (rc != 0)
		{
			fds_free_and_destroy(&dummy);
			continue;
		}

		dummy->set_time = false;
		fds_append(dummy);

		atomic_set(&dummy_is_sent, 1);
	}

	printk("Timer thread exit.\n");
	return 0;
}

