#include "fds.h"

#ifndef __KERNEL__
#define __KERNEL__
#endif

#ifndef MODULE
#define MODULE
#endif

int sys_no = 0;
int is_sys_dst = 0;

static int __init fds_init(void)
{ 
	int rc = 0;

#ifdef NINE_BRIDGE_IO_FUNC_REF
	fds_refs_init();
#endif

	/* 文件系统初始化 */
	rc = relay_init();
	if (rc != 0)
	{
		printk("relay_init failed, return %d\n", rc);
		return -1;
	}

	/* 初始化调度线程 */
	rc = dispatch_start();
	if (rc != 0)
	{
		printk("dispatch_start failed, return %d\n", rc);
		return -1;
	}

	/* 内核函数挂载 */
	rc = fds_hook_init();
	if (rc != 0)
	{
		printk("fds_set_sc_table failed\n");
		return -1;
	}

	printk("FDS run sys_no:[%d] is_sys_dst:[%d].......\n", sys_no, is_sys_dst);
	return 0;
}

/* TODO: 将fds_hook_uninit放到最前面去... Done */
/* TODO: 清除内部缓存列表 (struct queue)... Done */
static void __exit fds_exit(void)
{
	/* 清除挂载函数 */
	fds_hook_uninit();

	/* 停掉调度线程 */
	dispatch_stop();

	/* 文件系统资源释放 */
	relay_cleanup();

	/* 清空控制信息 */
	watch_path_cleanup();
	monitor_cleanup();

	/* 等待清除挂载函数完成 */
	wait_for_unhook_completion();

	printk("FDS exit...\n");
}

MODULE_LICENSE("Dual BSD/GPL");

module_init(fds_init);
module_param(sys_no, int, 0);
module_param(is_sys_dst, int, 0);
module_exit(fds_exit);

