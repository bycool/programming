#include "fds.h"

extern int dmp_mem;

int init_fds_foperate_info(struct fds_foperate_info *info)
{
	info->name = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);
    if(!info->name) 
    {
        printk("file:%s line:%d kmalloc size:%d error\n", __FILE__, __LINE__, PATH_MAX);
        return -1;
    }
    info->name[0] = 0;

    info->mtime = fds_get_mtime();
	info->name_len = 0;
	info->op_type = 0;
	info->op_inode = 0;

	info->mapid_cnt = 0;
	info->mapid = (char*)kmalloc(32*sizeof(char), GFP_ATOMIC); //max mapid
	info->mapid[0] = 0;

	info->args = 0;

    return 0;
}

void zero_fds_open_info(struct fds_open_info *info)
{
	info->flag = 0;
	info->mode = 0;
}

void zero_fds_write_info(struct fds_write_info *info)
{
	info->offset = 0;
	info->content_len = 0;
	info->content = 0;
}

void zero_fds_mkdir_info(struct fds_mkdir_info *info)
{
	info->mode = 0;
}

void zero_fds_rename_info(struct fds_rename_info *info)
{
	info->new_name = 0;
}

void zero_fds_truncate_info(struct fds_truncate_info *info)
{
	info->length = 0;
}

void zero_fds_chown_info(struct fds_chown_info *info)
{
	info->user = 0;
	info->group = 0;
	info->flag = 0;
}

void zero_fds_chmod_info(struct fds_chmod_info *info)
{
	info->mode = 0;
}

void zero_fds_link_info(struct fds_link_info *info)
{
	info->flag = 0;
	info->new_name = 0;
}

asmlinkage long fds_open(const char __user *filename, int flag, int mode)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_open_info     args;
        loff_t file_size = 0;

        info.name = 0;

	rc = old_open(filename, flag & (~FDS_O_OPENFORMD5), mode);
	if (rc >= 0 && watch_path_ready() && need_capture_io_nowrite())
	{
		if(init_fds_foperate_info(&info))
                    goto ret;

		zero_fds_open_info(&args);

		//printk("func:%s line:%d path:%s\n", __func__, __LINE__, filename);
		info.name_len = fds_get_fullpath_by_fn(filename, info.name, &info.op_inode,
				PATH_MAX, &file_size);

		//printk("func:%s line:%d path:%s filesize:%d\n", __func__, __LINE__, info.name, file_size);
		if (info.name_len == 0 || file_size > 0 || !monitored(info.name, false, info.mapid_cnt, info.mapid))
		{
                    goto ret;
		}

		if ((flag & FDS_O_OPENFORMD5) != 0)
			add_to_monitor_list(rc, info.name, info.name_len, 0);

		if ((flag & O_CREAT) != 0 || (flag & FDS_O_OPENFORMD5) != 0)
		{
			args.mode = mode;
			args.flag = flag;

			info.op_type = FDS_NR_OPEN;
			info.args = &args;

			fds_add_to_queue(&info);
		}
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_openat(
		int dfd, const char __user* filename, int flags, int mode)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_open_info args;

        info.name = 0;

	rc = old_openat(dfd, filename, flags, mode);
	if (rc >= 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                    goto ret;

		zero_fds_open_info(&args);

		info.name_len = fds_get_fullpath(dfd, filename, info.name, &info.op_inode,
				PATH_MAX);
		if (info.name_len  == 0 || !monitored(info.name, false, info.mapid_cnt, info.mapid))
		{
                    goto ret;
		}

		if ((flags & O_CREAT) != 0)
		{
			args.mode = mode;
			args.flag = flags;

			info.op_type = FDS_NR_OPEN;
			info.args = &args;

			fds_add_to_queue(&info);
		}
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_creat(const char __user* pathname, int mode)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_open_info args;

        info.name = 0;

	rc = old_creat(pathname, mode);
	if (rc >= 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                    goto ret;

		zero_fds_open_info(&args);

		info.name_len = fds_get_fullpath_by_fn(pathname, info.name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0 || !monitored(info.name, false, info.mapid_cnt, info.mapid))
		{
                    goto ret;
		}

		args.mode = mode;
		args.flag = O_CREAT | O_TRUNC;

		info.op_type = FDS_NR_OPEN;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

static void devide_and_send(struct fds_foperate_info* pinfo,
		const char __user* buf, long size)
{
	long nleft = size;
	const char* ptr = buf;
	struct fds_write_info* pargs = pinfo->args;

	while (nleft > 0)
	{
		pargs->content = ptr;
		pargs->content_len = nleft;
		if (pargs->content_len > MAX_CONTENT_LEN)
			pargs->content_len = MAX_CONTENT_LEN;

		fds_add_to_queue(pinfo);

		ptr += pargs->content_len;
		nleft -= pargs->content_len;
		pargs->offset += pargs->content_len;
	}
}

asmlinkage long fds_write(unsigned int fd, const char __user* buf, size_t len)
{
	long rc = -1;
	long queue_mem = 0;

	struct fds_foperate_info info;
	struct fds_write_info args;

        info.name = 0;

	REF_INC(fds_write);

	rc = old_write(fd, buf, len);
	if (rc > 0 && watch_path_ready() && need_capture_io())
	{
                if(init_fds_foperate_info(&info))
                    goto ret;

		zero_fds_write_info(&args);

		info.name_len = fds_get_fullpath_by_fd(fd, info.name, &info.op_inode,
				PATH_MAX);

		//printk("func:%s line:%d path:%s\n", __func__, __LINE__, info.name);
		if (info.name_len > 0 && monitored(info.name, false, info.mapid_cnt, info.mapid))
		{
			queue_mem = get_kern_mem();

			if(dmp_mem + (queue_mem / 1024 / 1024) > 200)
			{
				printk("func:%s line:%d dmp_mem:%dM queue_mem:%ld >200 msleep(1500)\n", __func__, __LINE__, dmp_mem, queue_mem);
				msleep(1500);
			}
			else if(dmp_mem + (queue_mem / 1024 / 1024) > 100)
			{
				printk("func:%s line:%d dmp_mem:%dM queue_mem:%ld >100 msleep(1000)\n", __func__, __LINE__, dmp_mem, queue_mem);
				msleep(1000);
			}

			args.offset = old_lseek(fd, 0, SEEK_CUR) - rc;

			info.op_type = FDS_NR_WRITE;
			info.args = &args;

			devide_and_send(&info, buf, rc);
		}
	}

	REF_DEC(fds_write);

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_writev(
		unsigned long fd, const struct iovec __user* vec, unsigned long vlen)
{
	long rc = -1;
        long queue_mem = 0;
	int i = 0;

	struct fds_foperate_info info;
	struct fds_write_info args;

	loff_t offset = old_lseek(fd, 0, SEEK_CUR);

        info.name = 0;

	REF_INC(fds_writev);

	rc = old_writev(fd, vec, vlen);
	if (rc > 0 && watch_path_ready() && need_capture_io())
	{
                if(init_fds_foperate_info(&info))
                    goto ret;

		zero_fds_write_info(&args);

		info.name_len = fds_get_fullpath_by_fd(fd, info.name, &info.op_inode, 
				PATH_MAX);
		if (info.name_len > 0 && monitored(info.name, false, info.mapid_cnt, info.mapid))
		{
                        queue_mem = get_kern_mem();

                        if(dmp_mem + (queue_mem / 1024 / 1024) > 200) 
                        {    
                                printk("func:%s line:%d dmp_mem:%dM queue_mem:%ld >200 msleep(1500)\n", __func__, __LINE__, dmp_mem, queue_mem);
                                msleep(1500);
                        }    
                        else if(dmp_mem + (queue_mem / 1024 / 1024) > 100) 
                        {    
                                printk("func:%s line:%d dmp_mem:%dM queue_mem:%ld >100 msleep(1000)\n", __func__, __LINE__, dmp_mem, queue_mem);
                                msleep(1000);
                        }

			info.op_type = FDS_NR_WRITE;
			info.args = &args;

			for (i = 0; i < vlen; ++i)
			{
				args.offset = offset;

				devide_and_send(&info, vec[i].iov_base,
						vec[i].iov_len);

				offset += vec[i].iov_len;
			}
		}
	}

	REF_DEC(fds_writev);

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_pwritev(
		unsigned long fd, const struct iovec __user* vec, unsigned long vlen,
		unsigned long pos_l, unsigned long pos_h)
{
	long rc = -1;
        long queue_mem = 0;
	int i = 0;

	struct fds_foperate_info info;
	struct fds_write_info args;


	loff_t offset = 0;

#if BITS_PER_LONG == 32
	offset = pos_l + ((((loff_t)pos_h) << 32) & 0xFFFFFFFF00000000);
#else
	offset = pos_l;
#endif

        info.name = 0;

	REF_INC(fds_pwritev);

	rc = old_pwritev(fd, vec, vlen, pos_l, pos_h);
	if (rc > 0 && watch_path_ready() && need_capture_io())
	{
                if(init_fds_foperate_info(&info))
                    goto ret;

		zero_fds_write_info(&args);

		info.name_len = fds_get_fullpath_by_fd(fd, info.name, &info.op_inode,
				PATH_MAX);
		if (info.name_len > 0 && monitored(info.name, false, info.mapid_cnt, info.mapid))
		{
                        queue_mem = get_kern_mem();

                        if(dmp_mem + (queue_mem / 1024 / 1024) > 200) 
                        {    
                                printk("func:%s line:%d dmp_mem:%dM queue_mem:%ld >200 msleep(1500)\n", __func__, __LINE__, dmp_mem, queue_mem);
                                msleep(1500);
                        }    
                        else if(dmp_mem + (queue_mem / 1024 / 1024) > 100) 
                        {    
                                printk("func:%s line:%d dmp_mem:%dM queue_mem:%ld >100 msleep(1000)\n", __func__, __LINE__, dmp_mem, queue_mem);
                                msleep(1000);
                        }

			info.op_type = FDS_NR_WRITE;
			info.args = &args;

		        //printk("func:%s line:%d name:%s\n", __func__, __LINE__, info.name);
			for (i = 0; i < vlen; ++i)
			{
				args.offset = offset;
		                //printk("func:%s line:%d offset:%lld v:%d\n", __func__, __LINE__, args.offset, i);

				devide_and_send(&info, vec[i].iov_base,
						vec[i].iov_len);

				offset += vec[i].iov_len;
			}
		}
	}

	REF_DEC(fds_pwritev);

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_pwrite64(
		unsigned int fd, const char __user* buf, size_t count, loff_t pos)
{
	long rc = -1;
        long queue_mem = 0;

	struct fds_foperate_info info;
	struct fds_write_info args;

        info.name = 0;

	REF_INC(fds_pwrite64);

	rc = old_pwrite64(fd, buf, count, pos);
	if (rc > 0 && watch_path_ready() && need_capture_io())
	{
                if(init_fds_foperate_info(&info))
                    goto ret;

		zero_fds_write_info(&args);

		info.name_len = fds_get_fullpath_by_fd(fd, info.name, &info.op_inode,
				PATH_MAX);
		if (info.name_len > 0 && monitored(info.name, false, info.mapid_cnt, info.mapid))
		{
                        queue_mem = get_kern_mem();

                        if(dmp_mem + (queue_mem / 1024 / 1024) > 200) 
                        {    
                                printk("func:%s line:%d dmp_mem:%dM queue_mem:%ld >200 msleep(1500)\n", __func__, __LINE__, dmp_mem, queue_mem);
                                msleep(1500);
                        }    
                        else if(dmp_mem + (queue_mem / 1024 / 1024) > 100) 
                        {    
                                printk("func:%s line:%d dmp_mem:%dM queue_mem:%ld >100 msleep(1000)\n", __func__, __LINE__, dmp_mem, queue_mem);
                                msleep(1000);
                        }

			args.offset = pos;

			info.op_type = FDS_NR_PWRITE64;
			info.args = &args;

			devide_and_send(&info, buf, count);
		}
	}

	REF_DEC(fds_pwrite64);

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_lseek(unsigned int fd, off_t offset, unsigned origin)
{
	return old_lseek(fd, offset, origin);
}

asmlinkage long fds_close(unsigned int fd)
{
	long rc = -1;

	struct fds_foperate_info info;

        info.name = 0;

	rc = old_close(fd);

	if (!need_capture_io_nowrite())
		return rc;

        if(init_fds_foperate_info(&info))
                goto ret;

	if (get_name_and_close(fd, info.name, &info.name_len, NULL))
	{
		info.op_type = FDS_NR_CLOSE;
		info.args = NULL;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_mkdir(const char __user* pathname, int mode)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_mkdir_info args;

        info.name = 0;

	rc = old_mkdir(pathname, mode);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                    goto ret;

		zero_fds_mkdir_info(&args);

		info.name_len = fds_get_fullpath_by_fn(pathname, info.name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0 || monitored(info.name, true, info.mapid_cnt, info.mapid))
		{
                    goto ret;
		}

		args.mode = mode;

		info.op_type = FDS_NR_MKDIR;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_unlink(const char __user* pathname)
{
	long rc = -1;

	struct fds_foperate_info info;

        info.name = 0;

        if(init_fds_foperate_info(&info))
        {
               rc = old_unlink(pathname);
               goto ret;
        }

	info.name_len = fds_get_fullpath_by_fn(pathname, info.name, &info.op_inode,
			PATH_MAX, 0);

	rc = old_unlink(pathname);
	if (rc == 0 && watch_path_ready() && need_capture_io())
	{
		if (info.name_len == 0 || !monitored(info.name, false, info.mapid_cnt, info.mapid))
		{
                    goto ret;
		}

		info.op_type = FDS_NR_UNLINK;
		info.args = NULL;

		fds_add_to_queue(&info);

	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_unlinkat(int dfd, const char __user* pathname, int flag)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_link_info args;

        info.name = 0;

        if(init_fds_foperate_info(&info))
        {
	       rc = old_unlinkat(dfd, pathname, flag);
               goto ret;
        }

	info.name_len = fds_get_fullpath(dfd, pathname, info.name, &info.op_inode,
			PATH_MAX);

	rc = old_unlinkat(dfd, pathname, flag);
	if (rc == 0 && watch_path_ready() && need_capture_io())
	{
		zero_fds_link_info(&args);

		if (info.name_len == 0 || !( monitored(info.name, false, info.mapid_cnt, info.mapid)))
		{
                    goto ret;
		}

		args.flag = flag;
		args.new_name = NULL;

		info.op_type = FDS_NR_UNLINKAT;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_link(const char __user* oldname, const char __user* newname)
{
	long rc = -1;

	int new_name_len = 0;
	char* new_name = 0;

	struct fds_foperate_info info;
	struct fds_link_info args;

        info.name = 0;

	rc = old_link(oldname, newname);
	if (rc == 0 && watch_path_ready()  && need_capture_io_nowrite())
	{
                int mapid0 = 0;
                int mapid1 = 0;

                if(init_fds_foperate_info(&info))
                   goto ret;

		zero_fds_link_info(&args);

		info.name_len = fds_get_fullpath_by_fn(oldname, info.name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0)
		{
                    goto ret;
		}

                new_name = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);
                if(!new_name) 
                    goto ret;

		new_name_len = fds_get_fullpath_by_fn(newname, new_name, &info.op_inode,
				PATH_MAX, 0);
		if (new_name_len == 0)
		{
                    goto ret;
		}

                mapid0 = monitored(info.name, false);
                mapid1 = monitored(new_name, false);

                if (!mapid0 && !mapid1)
                {    
                    goto ret; 
                }    

                //printk("line:%d mapid0:%d mapid1:%d\n", __LINE__, mapid0, mapid1);
                if(mapid0)
                    info.mapid = mapid0;
                else 
                    info.mapid = mapid1;

		args.new_name = new_name;

		info.op_type = FDS_NR_LINK;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

        if(new_name)
            kfree(new_name);

	return rc;
}

asmlinkage long fds_linkat(
		int olddfd, const char __user* oldname,
		int newdfd, const char __user* newname, int flag)
{
	long rc = -1;

        char* new_name = 0;
	int new_name_len = 0;

	struct fds_foperate_info info;
	struct fds_link_info args;

        info.name = 0;

	rc = old_linkat(olddfd, oldname, newdfd, newname, flag);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                int mapid0 = 0;
                int mapid1 = 0;

                if(init_fds_foperate_info(&info))
                   goto ret;

		zero_fds_link_info(&args);

		info.name_len = fds_get_fullpath(olddfd, oldname, info.name, &info.op_inode,
				PATH_MAX);
		if (info.name_len == 0)
		{
                    goto ret;
		}

                new_name = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);
                if(!new_name)
                    goto ret;

		new_name_len = fds_get_fullpath(newdfd, newname, new_name, &info.op_inode,
				PATH_MAX);
		if (new_name_len == 0)
		{
                    goto ret;
		}

                mapid0 = monitored(info.name, false);
                mapid1 = monitored(new_name, false);

                if (!mapid0 && !mapid1)
                {    
                    goto ret; 
                }    

                //printk("line:%d mapid0:%d mapid1:%d\n", __LINE__, mapid0, mapid1);
                if(mapid0)
                    info.mapid = mapid0;
                else 
                    info.mapid = mapid1;

		args.new_name = new_name;
		args.flag = flag;

		info.op_type = FDS_NR_LINKAT;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

        if(new_name)
            kfree(new_name);

	return rc;
}

asmlinkage long fds_symlink(
		const char __user* oldname, const char __user* newname)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_link_info args;

        char* new_name = 0;
	int new_name_len = 0;

        info.name = 0;

	rc = old_symlink(oldname, newname);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;

		zero_fds_link_info(&args);

                new_name = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);
                if(!new_name)
                    goto ret;

		info.name_len = fds_get_fullpath_by_fn(oldname, info.name, &info.op_inode,
				PATH_MAX, 0);
		new_name_len = fds_get_fullpath_by_fn(newname, new_name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0 || new_name_len == 0)
		{
                    goto ret;
		}

		if (!(info.mapid = monitored(new_name, false)))
		{
                    goto ret;
		}

		args.new_name = new_name;

		info.op_type = FDS_NR_SYMLINK;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

        if(new_name)
            kfree(new_name);

	return rc;
}

asmlinkage long fds_symlinkat(
		const char __user* oldname, int newdfd, const char __user* newname)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_link_info args;

        char* new_name = 0;
	int new_name_len = 0;

        info.name = 0;

	rc = old_symlinkat(oldname, newdfd, newname);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;

		zero_fds_link_info(&args);

                new_name = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);
                if(!new_name)
                    goto ret;

		info.name_len = fds_get_fullpath_by_fn(oldname, info.name, &info.op_inode,
				PATH_MAX, 0);
		new_name_len = fds_get_fullpath(newdfd, newname, new_name, &info.op_inode,
				PATH_MAX);
		if (info.name_len == 0 || new_name_len == 0)
		{
                    goto ret;
		}

		if (!(info.mapid = monitored(new_name, false)))
		{
                    goto ret;
		}

		args.new_name = new_name;

		info.op_type = FDS_NR_SYMLINK;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

        if(new_name)
            kfree(new_name);

	return rc;
}


asmlinkage long fds_rename(const char __user* oldnm, const char __user* newnm)
{
	long rc = -1;

        char* new_name = 0;
	int new_name_len = 0;

	struct fds_foperate_info info;
	struct fds_rename_info args;

        info.name = 0;

	rc = old_rename(oldnm, newnm);
	if (rc == 0 && watch_path_ready() && need_capture_io())
	{
                int mapid0 = 0;
                int mapid1 = 0;

                if(init_fds_foperate_info(&info))
                   goto ret; 

                zero_fds_rename_info(&args);

		info.name_len = fds_get_fullpath_by_fn(oldnm, info.name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0)
		{
                    goto ret;
		}

                new_name = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);
                if(!new_name)
                    goto ret;

		new_name_len = fds_get_fullpath_by_fn(newnm, new_name, &info.op_inode,
				PATH_MAX, 0);
		if (new_name_len == 0)
		{
                    goto ret;
		}

                mapid0 = monitored(info.name, false);
                mapid1 = monitored(new_name, false);

		if (!mapid0 && !mapid1)
		{
                    goto ret;
		}

                //printk("line:%d mapid0:%d mapid1:%d\n", __LINE__, mapid0, mapid1);
                if(mapid0)
                    info.mapid = mapid0;
                else
                    info.mapid = mapid1;

		args.new_name = new_name;

		info.op_type = FDS_NR_RENAME;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

        if(new_name)
            kfree(new_name);

	return rc;
}

asmlinkage long fds_renameat(
		int olddfd, const char __user* oldname,
		int newdfd, const char __user* newname)
{
	long rc = -1;

        char* new_name = 0;
	int new_name_len = 0;

	struct fds_foperate_info info;
	struct fds_rename_info args;

        info.name = 0;

	rc = old_renameat(olddfd, oldname, newdfd, newname);
	if (rc == 0 && watch_path_ready() && need_capture_io())
	{
                int mapid0 = 0; 
                int mapid1 = 0;

                if(init_fds_foperate_info(&info))
                   goto ret;

		zero_fds_rename_info(&args);

                new_name = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);
                if(!new_name)
                    goto ret;

		info.name_len = fds_get_fullpath_by_fn(oldname, info.name, &info.op_inode,
				PATH_MAX, 0);
		new_name_len = fds_get_fullpath_by_fn(newname, new_name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0 || new_name_len == 0)
		{
                    goto ret;
		}

                mapid0 = monitored(info.name, false);
                mapid1 = monitored(new_name, false);

                if (!mapid0 && !mapid1)
                {    
                    goto ret; 
                }    

                //printk("line:%d mapid0:%d mapid1:%d\n", __LINE__, mapid0, mapid1);
                if(mapid0)
                    info.mapid = mapid0;
                else 
                    info.mapid = mapid1;

		args.new_name = new_name;

		info.op_type = FDS_NR_RENAME;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

        if(new_name)
            kfree(new_name);

	return rc;
}

asmlinkage long fds_truncate(const char __user* pathname, long length)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_truncate_info args;

        info.name = 0;

	rc = old_truncate(pathname, length);
	if (rc == 0 && watch_path_ready() && need_capture_io())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;

		zero_fds_truncate_info(&args);

		info.name_len = fds_get_fullpath_by_fn(pathname, info.name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                    goto ret;
		}

		args.length = length;

		info.op_type = FDS_NR_TRUNCATE;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_ftruncate(unsigned int fd, unsigned long length)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_truncate_info args;

        info.name = 0;

	rc = old_ftruncate(fd, length);
	if (rc == 0 && watch_path_ready() && need_capture_io())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;

		zero_fds_truncate_info(&args);

		info.name_len = fds_get_fullpath_by_fd(fd, info.name, &info.op_inode,
				PATH_MAX);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                    goto ret;
		}

		args.length = length;

		info.op_type = FDS_NR_FTRUNCATE;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

#if BITS_PER_LONG == 32
asmlinkage long fds_truncate64(const char __user* path, loff_t length)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_truncate_info args;

        info.name = 0;

	rc = old_truncate64(path, length);
	if (rc == 0 && watch_path_ready() && need_capture_io())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;

		zero_fds_truncate_info(&args);

		info.name_len = fds_get_fullpath_by_fn(path, info.name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                    goto ret;
		}

		args.length = length;

		info.op_type = FDS_NR_TRUNCATE64;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return 0;
}

asmlinkage long fds_ftruncate64(unsigned int fd, loff_t length)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_truncate_info args;

        info.name = 0;

	rc = old_ftruncate64(fd, length);
	if (rc == 0 && watch_path_ready() && need_capture_io())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;

		zero_fds_truncate_info(&args);

		info.name_len = fds_get_fullpath_by_fd(fd, info.name, &info.op_inode,
				info.name_len);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                    goto ret;
		}

		args.length = length;

		info.op_type = FDS_NR_FTRUNCATE64;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return 0;
}
#endif


asmlinkage long fds_rmdir(const char __user* pathname)
{
	long rc = -1;

	struct fds_foperate_info info;

        info.name = 0;

        if(init_fds_foperate_info(&info))
        {
            rc = old_rmdir(pathname);
            goto ret;
        }

	info.name_len = fds_get_fullpath_by_fn(pathname, info.name, &info.op_inode,
			PATH_MAX, 0);

	rc = old_rmdir(pathname);
	if (rc == 0 && watch_path_ready() && need_capture_io())
	{
		if (info.name_len > 0 && info.name[info.name_len - 1] != '/')
			info.name[info.name_len++] = '/';
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, true)))
		{
                    goto ret;
		}

		info.op_type = FDS_NR_RMDIR;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_chown(const char __user* filename, uid_t user, gid_t group)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_chown_info args;

        info.name = 0;

	rc = old_chown(filename, user, group);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;

		zero_fds_chown_info(&args);

		info.name_len = fds_get_fullpath_by_fn(filename, info.name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                    goto ret;
		}

		args.user = user;
		args.group = group;
		args.flag = -1;

		info.op_type = FDS_NR_CHOWN;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_lchown(const char __user* filename, uid_t user, gid_t group)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_chown_info args;

        info.name = 0;

	rc = old_lchown(filename, user, group);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;
                
		zero_fds_chown_info(&args);

		info.name_len = fds_get_fullpath_by_fn(filename, info.name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                    goto ret;
		}

		args.user = user;
		args.group = group;
		args.flag = -1;

		info.op_type = FDS_NR_LCHOWN;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_fchown(unsigned int fd, uid_t user, gid_t group)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_chown_info args;

        info.name = 0;

	rc = old_fchown(fd, user, group);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;
                
		zero_fds_chown_info(&args);

		info.name_len = fds_get_fullpath_by_fd(fd, info.name, &info.op_inode,
				PATH_MAX);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                   goto ret;
		}

		args.user = user;
		args.group = group;
		args.flag = -1;

		info.op_type = FDS_NR_FCHOWN;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_fchownat(int dfd, const char __user* filename,
		uid_t user, gid_t group, int flag)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_chown_info args;

        info.name = 0;

	rc = old_fchownat(dfd, filename, user, group, flag);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;
                
		zero_fds_chown_info(&args);

		info.name_len = fds_get_fullpath(dfd, filename, info.name, &info.op_inode,
				PATH_MAX);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                    goto ret;
		}

		args.user = user;
		args.group = group;
		args.flag = flag;

		info.op_type = FDS_NR_FCHOWNAT;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_chmod(const char __user* filename, mode_t mode)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_chmod_info args;

        info.name = 0;

	rc = old_chmod(filename, mode);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;
                
		zero_fds_chmod_info(&args);

		info.name_len = fds_get_fullpath_by_fn(filename, info.name, &info.op_inode,
				PATH_MAX, 0);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                   goto ret;
		}

		args.mode = mode;

		info.op_type = FDS_NR_CHMOD;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_fchmod(unsigned int fd, mode_t mode)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_chmod_info args;

        info.name = 0;

	rc = old_fchmod(fd, mode);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;
                
		zero_fds_chmod_info(&args);

		info.name_len = fds_get_fullpath_by_fd(fd, info.name, &info.op_inode,
				PATH_MAX);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                    goto ret;
		}

		args.mode = mode;

		info.op_type = FDS_NR_FCHMOD;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}

asmlinkage long fds_fchmodat(int dfd, const char __user* filename, mode_t mode)
{
	long rc = -1;

	struct fds_foperate_info info;
	struct fds_chmod_info args;

        info.name = 0;

	rc = old_fchmodat(dfd, filename, mode);
	if (rc == 0 && watch_path_ready() && need_capture_io_nowrite())
	{
                if(init_fds_foperate_info(&info))
                   goto ret;
                
		zero_fds_chmod_info(&args);

		info.name_len = fds_get_fullpath(dfd, filename, info.name, &info.op_inode,
				PATH_MAX);
		if (info.name_len == 0 || !(info.mapid = monitored(info.name, false)))
		{
                    goto ret;
		}

		args.mode = mode;

		info.op_type = FDS_NR_FCHMOD;
		info.args = &args;

		fds_add_to_queue(&info);
	}

ret:
        if(info.name)
            kfree(info.name);

	return rc;
}



