#include "fds.h"

#define HEADER_FIXPART_LEN 28

static atomic_t serial_num = {0};

static int index_for_operation(unsigned char op_code);
static int serialize_header(char* buffer, int size,
	const struct fds_foperate_info* pinfo, int total_bytes);

static inline int get_length_for_dummy(const void* data);
static inline int get_length_for_open(const void* data);
static inline int get_length_for_write(const void* data);
static inline int get_length_for_mkdir(const void* data);
static inline int get_length_for_link(const void* data);
static inline int get_length_for_close(const void* data);
static inline int get_length_for_rename(const void* data);
static inline int get_length_for_truncate(const void* data);
static inline int get_length_for_rmdir(const void* data);
static inline int get_length_for_chown(const void* data);
static inline int get_length_for_chmod(const void* data);
static inline int get_length_for_fullfinish(const void* data);
static void serialize_for_open(const void* data, char* buffer, int size);
static void serialize_for_write(const void* data, char* buffer, int size);
static void serialize_for_mkdir(const void* data, char* buffer, int size);
static void serialize_for_link(const void* data, char* buffer, int size);
static void serialize_for_rename(const void* data, char* buffer, int size);
static void serialize_for_truncate(const void* data, char* buffer, int size);
static void serialize_for_chown(const void* data, char* buffer, int size);
static void serialize_for_chmod(const void* data, char* buffer, int size);

static struct serialize_operations ops[] =
{
#if BITS_PER_LONG == 32
	{FDS_NR_TRUNCATE64, get_length_for_truncate, serialize_for_truncate},
	{FDS_NR_FTRUNCATE64, get_length_for_truncate, serialize_for_truncate},
#endif
	{FDS_NR_DUMMY, get_length_for_dummy, NULL},
	{FDS_NR_OPEN,  get_length_for_open,  serialize_for_open },
	{FDS_NR_FSYNC, get_length_for_open,  serialize_for_open },
	{FDS_NR_WRITE, get_length_for_write, serialize_for_write},
	{FDS_NR_PWRITE64, get_length_for_write, serialize_for_write},
	{FDS_NR_CLOSE, get_length_for_close, NULL},
	{FDS_NR_MKDIR, get_length_for_mkdir, serialize_for_mkdir},
	{FDS_NR_UNLINK, get_length_for_link, NULL},
	{FDS_NR_UNLINKAT, get_length_for_link, serialize_for_link},
	{FDS_NR_LINK, get_length_for_link, serialize_for_link},
	{FDS_NR_LINKAT, get_length_for_link, serialize_for_link},
	{FDS_NR_SYMLINK, get_length_for_link, serialize_for_link},
	{FDS_NR_RENAME, get_length_for_rename, serialize_for_rename},
	{FDS_NR_TRUNCATE, get_length_for_truncate, serialize_for_truncate},
	{FDS_NR_FTRUNCATE, get_length_for_truncate, serialize_for_truncate},
	{FDS_NR_RMDIR, get_length_for_rmdir, NULL},
	{FDS_NR_CHOWN, get_length_for_chown, serialize_for_chown},
	{FDS_NR_LCHOWN, get_length_for_chown, serialize_for_chown},
	{FDS_NR_FCHOWN, get_length_for_chown, serialize_for_chown},
	{FDS_NR_FCHOWNAT, get_length_for_chown, serialize_for_chown},
	{FDS_NR_CHMOD, get_length_for_chmod, serialize_for_chmod},
	{FDS_NR_FCHMOD, get_length_for_chmod, serialize_for_chmod},
	{FDS_NR_FCHMODAT, get_length_for_chmod, serialize_for_chmod},
	{FDS_NR_FULLFINISH, get_length_for_fullfinish, NULL}
};


int serialize(const struct fds_foperate_info* pinfo, char** buf, int* size)
{
	int head_len = 0;
	int body_len = 0;

	int index = index_for_operation(pinfo->op_type);
	if (index == -1)
	{
		printk("unsupported operation, code[%u]\n",
			(unsigned int)pinfo->op_type);
		return FDS_E_INVL;
	}

	if (ops[index].get_length == NULL)
		return FDS_E_INVL;

	head_len = HEADER_FIXPART_LEN + pinfo->name_len;
	body_len = ops[index].get_length(pinfo->args);

	*size = head_len + body_len;
	if (pinfo->op_type == FDS_NR_DUMMY)
		*buf = (char*)kmalloc(head_len, GFP_ATOMIC);
	else
		*buf = (char*)kmalloc(*size, GFP_ATOMIC);
	if (*buf == NULL)
	{
		fds_relay_notify_memfull();
		printk("kmalloc failed for %d bytes\n", *size);
		return FDS_E_ALLOC;
	}

	/* 序列化头部 */
	serialize_header(*buf, *size, pinfo, *size);

	/* 序列化数据部分 */
	if (ops[index].serialize_body != NULL)
		ops[index].serialize_body(pinfo->args, *buf+head_len, body_len);

	return FDS_OK;
}

int serial_length(const struct fds_foperate_info* pinfo)
{
	int head_len = 0;
	int body_len = 0;

	int index = index_for_operation(pinfo->op_type);
	if (index == -1)
	{
		printk("unsupported operation, code[%u]\n",
			(unsigned int)pinfo->op_type);
		return -1;
	}

	if (ops[index].get_length == NULL)
		return -1;

	head_len = HEADER_FIXPART_LEN + pinfo->name_len;
	body_len = ops[index].get_length(pinfo->args);

	return head_len + body_len;
}

int serialize_for_error(
	const struct fds_foperate_info* info, char* buffer, int* size)
{
	int head_len = 0;
	int body_len = 0;

	int index = index_for_operation(info->op_type);
	if (index == -1)
		return FDS_E_INVL;

	head_len = HEADER_FIXPART_LEN + info->name_len;
	body_len = 1;

	figure_to_bytes(buffer + 0, 4, head_len + body_len);
	figure_to_bytes(buffer + 4, 4, atomic_add_return(1, &serial_num));
	figure_to_bytes(buffer + 8, 1, FDS_NR_ESYNC);
	figure_to_bytes(buffer + 9, 2, info->name_len);
	if (info->name_len > 0)
		memcpy(buffer + HEADER_FIXPART_LEN, info->name, info->name_len);

	figure_to_bytes(buffer + head_len, 1, info->op_type);

	return FDS_OK;
}


static int index_for_operation(unsigned char op_code)
{
	int i = 0;
	for (i = 0; i < sizeof(ops) / sizeof(ops[0]); ++i)
	{
		if (ops[i].op_code == op_code)
			return i;
	}

	return -1;
}

static int serialize_header(char* buffer, int size,
	const struct fds_foperate_info* info, int total_bytes)
{
	figure_to_bytes(buffer + 0, 4, total_bytes);
	figure_to_bytes(buffer + 4, 4, atomic_add_return(1, &serial_num));
	figure_to_bytes(buffer + 8, 1, info->op_type);
    figure_to_bytes(buffer + 9, 8, info->op_inode);
	figure_to_bytes(buffer + 17, 8, info->mtime);
	figure_to_bytes(buffer + 25, 1, info->mapid);
	figure_to_bytes(buffer + 26, 2, info->name_len);

	if (info->name_len > 0)
		memcpy(buffer + HEADER_FIXPART_LEN, info->name, info->name_len);

	return HEADER_FIXPART_LEN + info->name_len;
}

static inline int get_length_for_dummy(const void* data)
{
	return SUBBUF_LEN_DATA - HEADER_FIXPART_LEN;
}

static inline int get_length_for_open(const void* data)
{
	return 8;
}

static void serialize_for_open(const void* data, char* buffer, int size)
{
	struct fds_open_info* pinfo = (struct fds_open_info*)data;

	figure_to_bytes(buffer + 0, 4, pinfo->flag);
	figure_to_bytes(buffer + 4, 4, pinfo->mode);
}

static inline int get_length_for_write(const void* data)
{
	return 8 + 4 + ((struct fds_write_info*)data)->content_len;
}

static void serialize_for_write(const void* data, char* buffer, int size)
{
	struct fds_write_info* pinfo = (struct fds_write_info*)data;
	int len = 0;

	figure_to_bytes(buffer + 0, 8, pinfo->offset);
	figure_to_bytes(buffer + 8, 4, pinfo->content_len);
	len = copy_from_user(buffer + 12, pinfo->content, pinfo->content_len);
}

static inline int get_length_for_close(const void* data)
{
	return 0;
}

static inline int get_length_for_mkdir(const void* data)
{
	return 4;
}

static void serialize_for_mkdir(const void* data, char* buffer, int size)
{
	struct fds_mkdir_info* pinfo = (struct fds_mkdir_info*)data;
	figure_to_bytes(buffer + 0, 4, pinfo->mode);
}

static inline int get_length_for_link(const void* data)
{
	struct fds_link_info* pinfo = (struct fds_link_info*)data;

	if (pinfo == NULL)
		return 0;

	if (pinfo->new_name == NULL)
		return 4 + 2;
	else
		return 4 + 2 + strlen(((struct fds_link_info*)data)->new_name);
}

static void serialize_for_link(const void* data, char* buffer, int size)
{
	struct fds_link_info* pinfo = (struct fds_link_info*)data;
	int name_len = 0;

	if (data == NULL)
		return ;

	if (pinfo->new_name != NULL)
		name_len = strlen(pinfo->new_name);

	figure_to_bytes(buffer + 0, 2, name_len);

	if (pinfo->new_name != NULL)
		memcpy(buffer + 2, pinfo->new_name, name_len);

	figure_to_bytes(buffer + 2 + name_len, 4, pinfo->flag);
}

static inline int get_length_for_rename(const void* data)
{
	struct fds_rename_info* pinfo = (struct fds_rename_info*)data;

	return 2 + strlen(pinfo->new_name);
}

static void serialize_for_rename(const void* data, char* buffer, int size)
{
	struct fds_rename_info* pinfo = (struct fds_rename_info*)data;

	int new_name_len = strlen(pinfo->new_name);
	figure_to_bytes(buffer, 2, new_name_len);
	memcpy(buffer + 2, pinfo->new_name, new_name_len);
}

static inline int get_length_for_truncate(const void* data)
{
	struct fds_truncate_info* pinfo = (struct fds_truncate_info*)data;
	return sizeof(pinfo->length);
}

static void serialize_for_truncate(const void* data, char* buffer, int size)
{
	struct fds_truncate_info* pinfo = (struct fds_truncate_info*)data;

	figure_to_bytes(buffer, sizeof pinfo->length, pinfo->length);
}

static inline int get_length_for_rmdir(const void* data)
{
	return 0;
}

static inline int get_length_for_chown(const void* data)
{
	return 8;
}

static void serialize_for_chown(const void* data, char* buffer, int size)
{
	struct fds_chown_info* pinfo = (struct fds_chown_info*)data;

	figure_to_bytes(buffer + 0, 4, pinfo->user);
	figure_to_bytes(buffer + 4, 4, pinfo->group);
}

static inline int get_length_for_chmod(const void* data)
{
	return 4;
}

static void serialize_for_chmod(const void* data, char* buffer, int size)
{
	struct fds_chmod_info* pinfo = (struct fds_chmod_info*)data;

	figure_to_bytes(buffer, 4, pinfo->mode);
}

static inline int get_length_for_fullfinish(const void* data)
{
	return 0;
}

