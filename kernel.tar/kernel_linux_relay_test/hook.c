#include "fds.h"
#include <asm/string.h>

static ULONG fds_clear_and_return_origcr0(void);
static void fds_setback_cr0(ULONG val);
static void* fds_getsyscalltable(void);

static unsigned int orig_cr0 = 0;
static void** syscall_table = NULL;

sys_open_t old_open = NULL;
sys_openat_t old_openat = NULL;
sys_creat_t old_creat = NULL;
sys_write_t old_write = NULL;
sys_writev_t old_writev = NULL;
sys_pwritev_t old_pwritev = NULL;
sys_pwrite64_t old_pwrite64 = NULL;
sys_lseek_t old_lseek = NULL;
sys_close_t old_close = NULL;
sys_mkdir_t old_mkdir = NULL;
sys_unlink_t old_unlink = NULL;
sys_unlinkat_t old_unlinkat = NULL;
sys_link_t old_link = NULL;
sys_linkat_t old_linkat = NULL;
sys_symlink_t old_symlink = NULL;
sys_symlinkat_t old_symlinkat = NULL;
sys_rename_t old_rename = NULL;
sys_renameat_t old_renameat = NULL;
sys_truncate_t old_truncate = NULL;
sys_ftruncate_t old_ftruncate = NULL;
sys_rmdir_t old_rmdir = NULL;
sys_chown_t old_chown = NULL;
sys_lchown_t old_lchown = NULL;
sys_fchown_t old_fchown = NULL;
sys_fchownat_t old_fchownat = NULL;
sys_chmod_t old_chmod = NULL;
sys_fchmod_t old_fchmod = NULL;
sys_fchmodat_t old_fchmodat = NULL;

#if BITS_PER_LONG == 32
sys_truncate64_t old_truncate64 = NULL;
sys_ftruncate64_t old_ftruncate64 = NULL;
#endif

atomic_t fds_ope_references[IDX_COUNT];

int fds_hook_init()
{
	int i = 0;
	for (i = 0; i < IDX_COUNT; ++i)
		atomic_set(&fds_ope_references[i], 0);

	syscall_table = (void**)fds_getsyscalltable();
	if (syscall_table == NULL)
		return -1;

	orig_cr0 = fds_clear_and_return_origcr0();

#if BITS_PER_LONG == 32
#define FDS_HOOK(function)\
do { \
	old_##function=(sys_##function##_t)syscall_table[__NR3264_##function]; \
	syscall_table[__NR3264_##function] = fds_##function; \
} while (0)
#else
#define FDS_HOOK(function) \
do { \
	old_##function = (sys_##function##_t)syscall_table[__NR_##function]; \
	syscall_table[__NR_##function] = fds_##function; \
} while (0)
#endif

	FDS_HOOK(open);
	FDS_HOOK(openat);
	FDS_HOOK(creat);

#if HAVE_PWRITEV
	FDS_HOOK(pwritev);
#endif

	FDS_HOOK(pwrite64);
	FDS_HOOK(lseek);
	FDS_HOOK(close);
	FDS_HOOK(write);
	FDS_HOOK(writev);
	FDS_HOOK(mkdir);
	FDS_HOOK(unlink);
	FDS_HOOK(unlinkat);
	FDS_HOOK(link);
	FDS_HOOK(linkat);
	FDS_HOOK(symlink);
	FDS_HOOK(symlinkat);
	FDS_HOOK(rename);
	FDS_HOOK(renameat);
	FDS_HOOK(truncate);
	FDS_HOOK(ftruncate);
	FDS_HOOK(rmdir);
	FDS_HOOK(chown);
	FDS_HOOK(lchown);
	FDS_HOOK(fchown);
	FDS_HOOK(fchownat);
	FDS_HOOK(chmod);
	FDS_HOOK(fchmod);
	FDS_HOOK(fchmodat);

#if BITS_PER_LONG == 32
	FDS_HOOK(truncate64);
	FDS_HOOK(ftruncate64);
#endif

#undef FDS_HOOK

	fds_setback_cr0(orig_cr0);

	printk("hook kernel api functions\n");

	return 0;
}

void fds_hook_uninit()
{
	if (syscall_table == NULL)
		return;

	orig_cr0 = fds_clear_and_return_origcr0();

#if BITS_PER_LONG == 32
#define FDS_UNHOOK(function) \
do { \
	if (old_##function != NULL) \
		syscall_table[__NR3264_##function] = old_##function; \
} while (0)
#else
#define FDS_UNHOOK(function) \
do { \
	if (old_##function != NULL) \
		syscall_table[__NR_##function] = old_##function; \
} while (0)
#endif

	FDS_UNHOOK(open);
	FDS_UNHOOK(openat);
	FDS_UNHOOK(creat);

#if HAVE_PWRITEV
	FDS_UNHOOK(pwritev);
#endif

	FDS_UNHOOK(pwrite64);
	FDS_UNHOOK(lseek);
	FDS_UNHOOK(close);
	FDS_UNHOOK(write);
	FDS_UNHOOK(writev);
	FDS_UNHOOK(mkdir);
	FDS_UNHOOK(unlink);
	FDS_UNHOOK(unlinkat);
	FDS_UNHOOK(link);
	FDS_UNHOOK(linkat);
	FDS_UNHOOK(symlink);
	FDS_UNHOOK(symlinkat);
	FDS_UNHOOK(rename);
	FDS_UNHOOK(renameat);
	FDS_UNHOOK(truncate);
	FDS_UNHOOK(ftruncate);
	FDS_UNHOOK(rmdir);
	FDS_UNHOOK(chown);
	FDS_UNHOOK(lchown);
	FDS_UNHOOK(fchown);
	FDS_UNHOOK(fchownat);
	FDS_UNHOOK(chmod);
	FDS_UNHOOK(fchmod);
	FDS_UNHOOK(fchmodat);

#if BITS_PER_LONG == 32
	FDS_UNHOOK(truncate64);
	FDS_UNHOOK(ftruncate64);
#endif

#undef FDS_UNHOOK

	fds_setback_cr0(orig_cr0);

	printk("removed hooks.\n");
}

void wait_for_unhook_completion()
{
#ifdef NINE_BRIDGE_IO_FUNC_REF

#define WAIT_COMPLETE(function) \
	do { \
		printk("Wait for " #function " to complete"); \
		while (REF_CNT(function) > 0) \
			msleep(5000); \
	} while (0)

	WAIT_COMPLETE(fds_write);
	WAIT_COMPLETE(fds_writev);

#if HAVE_PWRITEV
	WAIT_COMPLETE(fds_pwritev);
#endif

	WAIT_COMPLETE(fds_pwrite64);

#undef WAIT_COMPLETE

#else
	int i = 0;

	for (i = 0; i < IDX_COUNT; ++i)
	{
		printk("Waiting for operation of index %d to complete.\n", i);

		while (REF_CNT(i) > 0)
			msleep(100);

		printk("Operation of index %d completed.\n", i);
	}
#endif

	printk("unhook completed.\n");
}



/************************************************************************
 *            不要修改下面的代码，除非你知道自己在干什么                *
 ************************************************************************/ 

#if BITS_PER_LONG == 32 //for 32-bits machine*/
static ULONG fds_clear_and_return_origcr0(void)
{
	unsigned int cr0 = 0;
	unsigned int cr1 = 0;
	unsigned int ret = -1;
		        
	__asm__ __volatile__ (
		"movl %%cr0,%%eax"
		:"=a"(cr0)
		                   );
	ret = cr0;
	cr0 = cr0 & 0xfffeffff;

	__asm__ __volatile__ (
		"movl %%eax,%%cr0"
		::"a"(cr0)
		);

	 return ret;
}

static void fds_setback_cr0(ULONG val)
{
	__asm__ __volatile__
	(
		"movl %%eax,%%cr0"
		::"a"(val)
	);
}


struct idt
{
	US1 offset_low,segment_select;
	UCHAR reserved,flags;
	US1 offset_high;
}__attribute__ ((packed));

struct idtr
{
	unsigned short limit;
	unsigned int base; //in 32bit mode, base address is 4 bytes
} __attribute__ ((packed));


static void* fds_getsyscalltable(void)
{
	unsigned char idtr[6],*shell,*sort;
	struct idt *idt;
	unsigned long system_call,sct;
	unsigned short offset_low,offset_high;
	char *p;
	int i;

	__asm__("sidt %0":"=m"(idtr));

	idt = (struct idt*)((*(unsigned long*)&idtr[2]) + 8 * 0x80);
	offset_low = idt->offset_low;
	offset_high = idt->offset_high;
	system_call = (offset_high)<<16 | offset_low;    
	shell = (char*)system_call;
	sort = "\xff\x14\x85";

	for(i = 0;i < 100-2;i++)
	{
		if(shell [ i ] == sort[0] && shell[i+1] == sort[1]
			&& shell[i+2] == sort[2])
			break;
	}

	p = &shell [ i ] + 3;
	sct = *(unsigned long*)p;

	return (void *)sct;    
}


#endif

#if BITS_PER_LONG == 64 //using for 64-bits machine
static ULONG fds_clear_and_return_origcr0(void)
{
	ULONG cr0 = 0;
	unsigned ret;

	asm volatile("mov %%cr0,%0 ; clts" : "=r" (cr0));
	ret = cr0;
	cr0 &= 0xfffffffffffeffff;

	__asm__ __volatile__
	(
		"movq %%rax,%%cr0"
		::"a"(cr0)
	);

	return ret;
}

static void fds_setback_cr0(ULONG val)
{
	__asm__ __volatile__
	(
		"movq %%rax,%%cr0"
		::"a"(val)
	);
}


struct idtr {
	unsigned short limit;
	unsigned long base; //in 64bit mode, base address is 8 bytes
} __attribute__ ((packed));


/**
* in long mode -- 64bit mode and compatity mode,
* every IDT entry has a 16-byte size
*/

struct idt {
	u16 offset_low;
	u16 segment;
	unsigned ist : 3, zero0 : 5, type : 5, dpl :2, p : 1;
	u16 offset_middle;
	u32 offset_high;
	u32 zero1;
} __attribute__ ((packed));


static void *memmem(const void *haystack, size_t haystack_len,
		    const void *needle, size_t needle_len)
{
	const char *begin;
	const char *const last_possible
		= (const char *) haystack + haystack_len - needle_len;

	/* The first occurrence of the empty string is deemed to occur at
	   the beginning of the string. 
	 */
	if (needle_len == 0)
		return (void *) haystack;

	/* Sanity check, otherwise the loop might search through the whole
	   memory. 
	 */
	if (__builtin_expect(haystack_len < needle_len, 0))
		return NULL;

	for (begin = (const char *) haystack; begin <= last_possible; ++begin)
	{
		if (begin[0] == ((const char *) needle)[0]
			&& !memcmp(begin + 1, needle + 1, needle_len - 1))
		{
			return (void *) begin;
		}
	}

	return NULL;
}

static void* fds_getsyscalltable(void)
{

#define OFFSET_SYSCALL 150
	unsigned long syscall_long, retval;
	char sc_asm[OFFSET_SYSCALL];

	rdmsrl(MSR_LSTAR, syscall_long);

	memcpy(sc_asm, (char*)syscall_long, OFFSET_SYSCALL);

	retval = (unsigned long)memmem(sc_asm, OFFSET_SYSCALL, "\xff\x14\xc5", 3);
	if ( retval != 0 ) 
	{
		retval = (unsigned long)(*(unsigned long*)(retval+3));
	} 
	else 
	{
		printk("long mode : memmem found nothing, returning NULL:( \n");
		retval = 0;
	}

	/* we must do it,otherwise the high 32-bit of retval would be wrong! */
	retval |= 0xffffffff00000000;
#undef OFFSET_SYSCALL

	return (void *)retval;
}

#endif

