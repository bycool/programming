#include "fds.h"

#if (LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 32))
static DEFINE_SPINLOCK(lock_context);
#else
static spinlock_t lock_context = SPIN_LOCK_UNLOCKED;
#endif

static LIST_HEAD(fds_head);

int add_to_monitor_list(int fd, const char* fullpath, int size, int full_sync)
{
	struct fds_monitored_file* node = NULL;

	node = (struct fds_monitored_file*)kmalloc(sizeof(*node) + size + 1,
		GFP_ATOMIC);
	if (node == NULL)
	{
		fds_relay_notify_memfull();
		return -1;
	}

	INIT_LIST_HEAD(&node->list);
	node->fd = fd;
	node->pid = current->pid;
	node->name_len = size;
	node->full_sync = full_sync;
	memcpy(node->name, fullpath, size);

	spin_lock_irq(&lock_context);
	list_add(&node->list, &fds_head);
	spin_unlock_irq(&lock_context);

	return 0;
}

bool get_name_and_close(int fd, char* fullpath, int* size, int* fsync)
{
	struct fds_monitored_file* node = NULL;

	spin_lock_irq(&lock_context);
	list_for_each_entry(node, &fds_head, list)
	{
		if (node->pid == current->pid && node->fd == fd)
		{
			list_del(&node->list);

			memcpy(fullpath, node->name, node->name_len);
			*size = node->name_len;

			if (fsync != NULL)
				*fsync = node->full_sync;

			kfree(node);

			spin_unlock_irq(&lock_context);
			return true;
		}
	}
	spin_unlock_irq(&lock_context);

	return false;
}

bool get_name_from_monitor_list(int fd, char* fullpath, int* size)
{
	struct fds_monitored_file* node = NULL;

	spin_lock_irq(&lock_context);
	list_for_each_entry(node, &fds_head, list)
	{
		if (node->pid == current->pid && node->fd == fd)
		{
			memcpy(fullpath, node->name, node->name_len);
			*size = node->name_len;

			spin_unlock_irq(&lock_context);
			return true;
		}
	}
	spin_unlock_irq(&lock_context);

	return false;
}

bool get_name_if_full_sync(int fd, char* fullpath, int* size)
{
	struct fds_monitored_file* node = NULL;

	spin_lock_irq(&lock_context);
	list_for_each_entry(node, &fds_head, list)
	{
		if (node->pid == current->pid && node->fd == fd)
		{
			if (node->full_sync == 0)
				break;

			memcpy(fullpath, node->name, node->name_len);
			*size = node->name_len;
			spin_unlock_irq(&lock_context);
			return true;
		}
	}
	spin_unlock_irq(&lock_context);

	return false;
}

/* TODO: 思考一下， 如何能保证析构操作正常完成 ...Done */
void monitor_cleanup()
{
	struct fds_monitored_file* node = NULL;
	struct fds_monitored_file* next = NULL;

	spin_lock_irq(&lock_context);
	if (!list_empty_careful(&fds_head))
	{
		list_for_each_entry_safe(node, next, &fds_head, list)
			kfree(node);
	}
	spin_unlock_irq(&lock_context);
}

