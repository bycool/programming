#include "fds.h"

static struct fds_queue head = {NULL, {0, NULL}}; /* 头节点不存放数据 */
static struct fds_queue* tail = &head;

static long max_memory = 2048l * 1024l * 1024l;
static atomic_long_t used_memory = ATOMIC_LONG_INIT(0);
long his_max_memory = 0;

#if (LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 32))
static DEFINE_SPINLOCK(lock_queue);
#else
static spinlock_t lock_queue = SPIN_LOCK_UNLOCKED;
#endif

static struct semaphore sem_queue = __SEMAPHORE_INITIALIZER(sem_queue, 0);

static void do_notify(const struct fds_foperate_info* pinfo);

void set_kern_max_memory(int mem)
{
	if (mem >=500)
        {
		max_memory = (long)mem * 1024l * 1024l;
                printk("USER SET KERNEL MAX MEM:%dM\n", mem);
        }
}

long get_kern_mem()
{
	return atomic_long_read(&used_memory);
}

long get_kern_his_max_mem()
{
	return his_max_memory;
}


int fds_alloc_and_init(struct fds_queue** queue)
{
	if (queue == NULL)
		return -1;

	*queue = (struct fds_queue*)kmalloc(sizeof(struct fds_queue),
		GFP_ATOMIC);
	if (*queue == NULL)
	{
		fds_relay_notify_memfull();
		return FDS_E_ALLOC;
	}

	(*queue)->next = NULL;
	(*queue)->node.buffer = NULL;
	(*queue)->node.size = 0;
	(*queue)->set_time = true;

	return FDS_OK;
}

void fds_free_and_destroy(struct fds_queue** queue)
{
	if (queue == NULL || *queue == NULL)
		return;

	if ((*queue)->node.buffer && (*queue)->node.buffer[8] != FDS_NR_DUMMY)
	{
		atomic_long_sub((*queue)->node.size, &used_memory);

#ifdef NINE_BRIDGE_SELFTEST
		printk("current memory: %ld\n", atomic_long_read(&used_memory));
#endif
	}

	if ((*queue)->node.buffer != NULL)
		kfree((*queue)->node.buffer);

	kfree(*queue);
	*queue = NULL;
}

void fds_queue_cleanup()
{
	struct fds_queue* pnode = NULL;
	struct fds_queue* next = NULL;

	spin_lock_irq(&lock_queue);

	next = head.next;

	while ((pnode = next) != NULL)
	{
		next = pnode->next;
		fds_free_and_destroy(&pnode);
	}

	head.next = NULL;
	tail = &head;

	his_max_memory = 0;
	spin_unlock_irq(&lock_queue);
}

void fds_append(struct fds_queue* queue)
{
	spin_lock_irq(&lock_queue);

	tail->next = queue;
	tail = queue;

	spin_unlock_irq(&lock_queue);

	up(&sem_queue);
}

struct fds_queue* fds_pop()
{
	struct fds_queue* rc = NULL;

	down(&sem_queue);

	spin_lock_irq(&lock_queue);
	if (tail == &head)
	{
		spin_unlock_irq(&lock_queue);
		return NULL;
	}

	rc = head.next;
	if (tail == head.next)
	{
		tail = &head;
		head.next = NULL;
	}
	else
		head.next = head.next->next;

	spin_unlock_irq(&lock_queue);

	if (rc != NULL)
		rc->next = NULL;

	return rc;
}

struct fds_queue* fds_queue_detach()
{
	struct fds_queue* rc = NULL;

	down(&sem_queue);

	spin_lock_irq(&lock_queue);
	if (tail == &head)
	{
		spin_unlock_irq(&lock_queue);
		return NULL;
	}

	rc = head.next;

	head.next = NULL;
	tail = &head;
	spin_unlock_irq(&lock_queue);

	return rc;
}

void fds_queue_op_unblock_once()
{
	up(&sem_queue);
}

bool dummy(const char* buffer, int size)
{
	return buffer[8] == FDS_NR_DUMMY;
}

static void do_notify(const struct fds_foperate_info* pinfo)
{
	char data[1024] = {0};
	int bytes = sizeof data;

	serialize_for_error(pinfo, data, &bytes);
	fds_relay_error(data, bytes);
}

/* TODO: when failed, actions should be taken to re-sync the file. ... Done */
void fds_add_to_queue(struct fds_foperate_info* pinfo)
{
	int rc = 0;
	struct fds_queue* queue = NULL;
	int length = 0;
	long int max_mem = 0;
        char *tmp_name = 0;

        tmp_name = (char*)kmalloc(pinfo->name_len, GFP_ATOMIC);
        if(!tmp_name) 
        {    
            printk("file:%s line:%d kmalloc size:%d error\n", __FILE__, __LINE__, pinfo->name_len);
            return;
        }    

        memcpy(tmp_name, pinfo->name, pinfo->name_len);
        kfree(pinfo->name);
        pinfo->name = tmp_name;

	length = serial_length(pinfo);
	if (length <= 0)
		return;
	else if (atomic_long_read(&used_memory) >= max_memory)
	{
		printk("Warning: Memory used %ld, max %ld. Package dropped.\n",
			atomic_long_read(&used_memory), max_memory);

		fds_relay_notify_memfull();
		return;
	}

	rc = fds_alloc_and_init(&queue);
	if (rc != 0)
	{
		if (rc == FDS_E_ALLOC)
			do_notify(pinfo);

		printk("alloc for queue failed\n");
		return;
	}

	rc = serialize(pinfo, &queue->node.buffer, &queue->node.size);
	if (rc != FDS_OK)
	{
		fds_free_and_destroy(&queue);

		if (rc == FDS_E_ALLOC)
			do_notify(pinfo);

		printk("serialize data failed\n");
		return;
	}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32))
	max_mem = atomic_long_add_return(length, &used_memory);
#else
	max_mem = atomic64_add_return(length, &used_memory);
#endif
	if (his_max_memory < max_mem)
	{
		his_max_memory = max_mem;
		printk("FDS: His max memory %ld\n", his_max_memory);
	}

#ifdef NINE_BRIDGE_SELFTEST
	printk("++++ current memory: %ld.\n", atomic_long_read(&used_memory));
#endif

#if 0
	printk("-----------------------------------------\n");
	printk("info.name     : %s\n", pinfo->name);
	printk("info.namelen  : %d\n", pinfo->name_len);
	printk("info.op_tyoe  : %x\n", pinfo->op_type);
	printk("info.op_inode : %lu\n", pinfo->op_inode);
	printk("info.mtime    : %lu\n", pinfo->mtime);
	printk("info.mapid    : %d\n", pinfo->mapid);
	printk("-----------------------------------------\n");
#endif

	fds_append(queue);
}

void fds_add_to_queue_emptyops(unsigned char op_type, int mapid)
{
	struct fds_foperate_info info;
        char *name = kmalloc(1, GFP_ATOMIC);

        if(!name)
        {
            printk("file:%s line:%d kmalloc size 1 error\n", __FILE__, __LINE__);
            return;
        }

	info.args = NULL;
	info.op_type = op_type;
	info.name_len = 1;
	info.mtime = fds_get_mtime();
   
        info.name = name;
	info.name[0] = '.';
	info.mapid = mapid;
	fds_add_to_queue(&info);

    kfree(info.name);
}


