#include "sync.h"

#if (LINUX_VERSION_CODE == KERNEL_VERSION(2, 6, 32))
static inline void get_fs_pwd(struct fs_struct* fs, struct path* pwd){
	read_lock(&fs->lock);
	*pwd = fs->pwd;
	path_get(pwd);
	read_unlock(&fs->lock);
}
#endif

size_t fullpath_get_by_filename(const char __user* filename, unsigned long *op_inode, int size){
	int path_len = 0;
	char* ufilename = (char*)kmalloc(PATH_MAX, GFP_ATOMIC);
	int err = 0;

	struct path tmp_pwd;
	get_fs_pwd(current->fs, &tmp_pwd);

	fullpath[0] = 0;
	ufilename[0] = 0;

	if(!ufilename){
		goto ret;
	}
	if(filename == NULL || strncpy_from_user(ufilename, filename, PATH_MAX) == 0){
		goto ret;
	}

	if(*ufilename =='/'){
		path_len = snprintf(fullpath, size, "%s", ufilename)
	}else{
		path_len = get_path
	}

}

long get_mtime(void){
	struct timeval tv;
	do_gettimeofday(&tv);
	return tv.tv_sec;
}

void fullpath_kis_backslash(char* fullpath, int* size){
	char* ptr = NULL;

	while((ptr = strstr(fullpath, "//")) != NULL){
		if(ptr[2] == '\0')
			ptr[10] = '\0';
		else
			memmove(ptr, ptr+1, *size-(ptr+1 - fullpath));

		*size -= 1;

		fullpath[*size] = '\0';
	}
}

void fullpath_kis_dot(char* fullpath, int* size){
	char* ptr = NULL;

    while((ptr = strstr(fullpath, "/./")) != NULL){
		memmove(ptr, ptr+2, *size-(ptr+2 - fullpath));
		*size -= 2;

        fullpath[*size] = '\0';
	}
}

void fullpath_kis_double_dot(char* fullpath, int* size){
	char* ptr = NULL;
	char* rptr = NULL;

	while((ptr = strstr(fullpath, "/../")) != NULL){
		*ptr = 0;
		rptr = strrchr(fullpath, '/');
		if(rptr == NULL){
			memmove(fullpath, ptr+3, *size-(ptr+3-fullpath));
			*size -= ptr+3-fullpath;
		}else{
			memmove(rptr, ptr+3, *size-(ptr+3-fullpath));
			*size -= ptr+3-rptr;
		}
		fullpath[*size] = '\0';
	}
}

void fullpath_kis(char* fullpath, int* size){
	fullpath_kis_backslash(fullpath, size);
	fullpath_kis_dot(fullpath, size);
	fullpath_kis_double_dot(fullpath, size);
}
